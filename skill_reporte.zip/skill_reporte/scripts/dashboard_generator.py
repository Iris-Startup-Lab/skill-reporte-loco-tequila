"""
dashboard_generator.py
======================
Genera un dashboard HTML auto-contenido con:
  - Filtros interactivos: semana, producto, canal, estado, año
  - KPI cards con paleta maroon
  - Gráficas Chart.js: barras agrupadas, líneas de tendencia (sin donas para análisis)
  - Tabla filtrable con ordenamiento
  - Botón de descarga CSV de datos filtrados

Paleta: Design.md (brand-maroon #6E1E28, highlight-cream #FBF3DD, etc.)
Chart.js vía CDN (sin costo).
"""

import json
import os
import base64
from typing import Optional
import pandas as pd
import numpy as np

import design_tokens as dt
from design_tokens import (
    BRAND_MAROON, BRAND_MAROON_DEEP, HIGHLIGHT_CREAM, PAGE_BG, RULE_LINE,
    HEADER_TEXT, SECTION_SUBTITLE, NEG_VALUE, POS_VALUE,
    PRODUCT_ORDER, PRODUCT_DISPLAY_NAMES, PRODUCT_COLORS,
    CANAL_ORDER, CANAL_COLORS,
    CHART_PLAN_LINE, CHART_LASTYEAR_AREA, CHART_GRID,
    fmt_currency, fmt_int,
)
from data_processor import LocoDataProcessor
from logo_processor import get_logo_for_html


# ---------------------------------------------------------------------------
# Serialización segura de datos a JSON
# ---------------------------------------------------------------------------

class _SafeEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (np.integer,)):
            return int(obj)
        if isinstance(obj, (np.floating,)):
            return float(obj)
        if isinstance(obj, (np.ndarray,)):
            return obj.tolist()
        if pd.isna(obj):
            return 0
        return super().default(obj)


def _to_json(obj) -> str:
    return json.dumps(obj, cls=_SafeEncoder, ensure_ascii=False)


# ---------------------------------------------------------------------------
# Preparar datos para el dashboard
# ---------------------------------------------------------------------------

def _prepare_data(proc: LocoDataProcessor) -> dict:
    """Prepara todos los datasets que el dashboard necesita."""
    df = proc.get_dataframe_dashboard()

    # Limpiar NaN
    df = df.fillna(0)
    df["fecha"] = df["fecha"].astype(str)

    # Filtros disponibles
    semanas   = sorted(df["semana_num"].dropna().unique().tolist())
    anios     = sorted(df["anio"].dropna().unique().tolist())
    productos = [PRODUCT_DISPLAY_NAMES.get(p, p) for p in PRODUCT_ORDER
                 if p in df["producto"].unique()]
    canales   = [c for c in CANAL_ORDER if c in df["canal"].unique()]
    estados   = sorted(df["estado"].dropna().unique().tolist())

    # Serie semanal (últimas 26 semanas) para gráfica principal
    serie_v = proc.get_serie_semanal(n_semanas=26)
    plan_df  = proc.get_plan_semanal(n_semanas=26)

    labels_sem = serie_v["label"].tolist() if not serie_v.empty else []
    totales_sem = [float(v) for v in serie_v.get("Total", pd.Series()).tolist()] if not serie_v.empty else []

    plan_dict = {}
    if not plan_df.empty:
        plan_dict = dict(zip(plan_df["label"], plan_df["plan_venta_sin_impuestos"].astype(float)))
    plan_vals = [plan_dict.get(lbl, 0) for lbl in labels_sem]

    # Por producto (últimas 26 semanas)
    product_series = {}
    for p in PRODUCT_ORDER:
        if p in serie_v.columns:
            product_series[PRODUCT_DISPLAY_NAMES.get(p, p)] = [
                float(v) for v in serie_v[p].tolist()
            ]

    # Ranking productos YTD
    ranking = proc.get_ranking_productos(mode="anual")
    ranking_labels  = [PRODUCT_DISPLAY_NAMES.get(r["producto"], r["producto"])
                       for _, r in ranking.iterrows()]
    ranking_ventas  = [float(r["ventas"]) for _, r in ranking.iterrows()]
    ranking_botellas = [float(r["botellas"]) for _, r in ranking.iterrows()]
    ranking_colors   = [PRODUCT_COLORS.get(r["producto"], "#999999")
                        for _, r in ranking.iterrows()]

    # Regional top 12
    df_reg = proc.get_analisis_regional(mode="anual").head(12)
    regional_labels = df_reg["region_o_estado"].tolist()
    regional_ventas = [float(v) for v in df_reg["ventas"].tolist()]

    # Canal breakdown
    serie_canal = proc.get_serie_semanal(n_semanas=26, group_by="canal")
    canal_series = {}
    for canal in CANAL_ORDER:
        if canal in serie_canal.columns:
            canal_series[canal] = [float(v) for v in serie_canal[canal].tolist()]

    # KPIs resumen
    resumen = proc.get_resumen_ejecutivo()

    # Tabla de datos completa (filtrable) — últimas 26 semanas del año actual
    y, w = proc.anio, proc.semana
    df_tabla = df[(df["anio"] == y) & (df["semana_num"] <= w)].copy()
    df_tabla = df_tabla.groupby(
        ["semana", "producto_display", "canal", "estado", "cliente"]
    ).agg(
        venta_sin_iva=("venta_sin_iva", "sum"),
        botellas=("botellas", "sum"),
        margen_pesos=("margen_pesos", "sum"),
    ).reset_index()
    df_tabla["margen_pct"] = (df_tabla["margen_pesos"] / df_tabla["venta_sin_iva"] * 100).fillna(0).round(1)
    tabla_records = df_tabla.head(2000).to_dict(orient="records")
    for rec in tabla_records:
        for k, v in rec.items():
            if isinstance(v, float) and (v != v):  # NaN
                rec[k] = 0

    return {
        "meta": {
            "semana": proc.semana,
            "anio": proc.anio,
            "semana_label": f"Semana {proc.semana:02d} · {proc.anio}",
        },
        "filtros": {
            "semanas": [int(s) for s in semanas],
            "anios": [int(a) for a in anios],
            "productos": productos,
            "canales": canales,
            "estados": estados,
        },
        "kpis": {
            "ventas_netas": float(resumen["actual"]["ventas_netas"]),
            "plan": float(resumen["plan"]["ventas_netas"]),
            "vs_plan_pct": float(resumen["vs_plan"]["pct"]),
            "vs_semana_ant_pct": float(resumen["vs_semana_anterior"]["pct"]),
            "vs_anio_ant_pct": float(resumen["vs_anio_anterior"]["pct"]),
            "ytd": float(resumen["ytd_actual"]["ventas_netas"]),
            "ytd_vs_ly_pct": float(resumen["ytd_vs_ly"]["pct"]),
            "botellas": float(resumen["actual"]["botellas"]),
            "margen_pct": float(resumen["actual"]["margen_pct"]),
            "ticket": float(resumen["actual"]["ticket_promedio"]),
        },
        "serie_semanal": {
            "labels": labels_sem,
            "totales": totales_sem,
            "plan": plan_vals,
            "por_producto": product_series,
            "por_canal": canal_series,
        },
        "ranking": {
            "labels": ranking_labels,
            "ventas": ranking_ventas,
            "botellas": ranking_botellas,
            "colors": ranking_colors,
        },
        "regional": {
            "labels": regional_labels,
            "ventas": regional_ventas,
        },
        "tabla": tabla_records,
        "oportunidades": proc.get_oportunidades_riesgos(),
        "product_colors": {PRODUCT_DISPLAY_NAMES.get(k, k): v for k, v in PRODUCT_COLORS.items()},
        "canal_colors": CANAL_COLORS,
    }


# ---------------------------------------------------------------------------
# Template HTML
# ---------------------------------------------------------------------------

def _build_html(data: dict, logo_svg: str = "") -> str:
    data_json = _to_json(data)

    # Colores CSS
    maroon      = BRAND_MAROON
    maroon_deep = BRAND_MAROON_DEEP
    cream       = HIGHLIGHT_CREAM
    neg_color   = NEG_VALUE
    grid_color  = CHART_GRID
    subtitle_c  = SECTION_SUBTITLE

    return f"""<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Ventas — Loco Tequila</title>
  <meta name="description" content="Dashboard ejecutivo de ventas semanales Loco Tequila con filtros interactivos y descarga de datos.">
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {{
      --brand-maroon:      {maroon};
      --brand-maroon-deep: {maroon_deep};
      --cream:             {cream};
      --neg:               {neg_color};
      --grid:              {grid_color};
      --sub:               {subtitle_c};
      --bg:                #F5F5F5;
      --card-bg:           #FFFFFF;
      --text:              #222222;
    }}

    * {{ box-sizing: border-box; margin: 0; padding: 0; }}

    body {{
      font-family: 'Poppins', sans-serif;
      background: var(--bg);
      color: var(--text);
      font-size: 13px;
    }}

    /* ── Header ── */
    header {{
      background: linear-gradient(135deg, var(--brand-maroon) 0%, var(--brand-maroon-deep) 100%);
      color: #fff;
      padding: 18px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 3px 12px rgba(110,30,40,0.35);
    }}
    header h1 {{ font-size: 1.4rem; font-weight: 700; letter-spacing: 0.3px; }}
    header .subtitle {{ font-size: 0.78rem; opacity: 0.85; margin-top: 2px; }}
    .logo-area {{
      display: flex;
      align-items: center;
      justify-content: flex-end;
    }}
    .logo-area img, .logo-area svg {{
      height: 50px;
      width: auto;
      object-fit: contain;
      filter: drop-shadow(0 1px 3px rgba(0,0,0,0.3));
    }}
    .logo-fallback {{
      text-align: right;
      font-size: 1.6rem;
      font-weight: 900;
      letter-spacing: 2px;
      color: #fff;
    }}
    .logo-fallback span {{ display: block; font-size: 0.55rem; font-weight: 400; letter-spacing: 4px; opacity: 0.8; }}

    /* ── Filter bar ── */
    .filter-bar {{
      background: var(--card-bg);
      border-bottom: 3px solid var(--brand-maroon);
      padding: 12px 32px;
      display: flex;
      flex-wrap: wrap;
      gap: 12px;
      align-items: center;
    }}
    .filter-bar label {{ font-size: 0.7rem; font-weight: 600; color: var(--sub); text-transform: uppercase; letter-spacing: 0.5px; }}
    .filter-bar select, .filter-bar input {{
      padding: 5px 10px;
      border: 1.5px solid #DDD;
      border-radius: 6px;
      font-size: 0.78rem;
      font-family: 'Poppins', sans-serif;
      background: #FAFAFA;
      transition: border-color 0.2s;
      min-width: 130px;
    }}
    .filter-bar select:focus, .filter-bar input:focus {{
      border-color: var(--brand-maroon);
      outline: none;
    }}
    .filter-group {{ display: flex; flex-direction: column; gap: 3px; }}
    .btn {{
      padding: 6px 16px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-family: 'Poppins', sans-serif;
      font-size: 0.78rem;
      font-weight: 600;
      transition: all 0.2s;
    }}
    .btn-primary {{
      background: var(--brand-maroon);
      color: #fff;
    }}
    .btn-primary:hover {{ background: var(--brand-maroon-deep); transform: translateY(-1px); }}
    .btn-secondary {{
      background: var(--cream);
      color: var(--brand-maroon);
      border: 1.5px solid var(--brand-maroon);
    }}
    .btn-secondary:hover {{ background: #f0e6e8; }}

    /* ── Main layout ── */
    main {{ padding: 20px 32px; max-width: 1600px; margin: 0 auto; }}

    /* ── KPI cards ── */
    .kpi-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
      gap: 14px;
      margin-bottom: 22px;
    }}
    .kpi-card {{
      background: var(--card-bg);
      border-radius: 10px;
      padding: 16px 18px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.07);
      border-left: 4px solid var(--brand-maroon);
      transition: transform 0.18s, box-shadow 0.18s;
    }}
    .kpi-card:hover {{ transform: translateY(-2px); box-shadow: 0 6px 18px rgba(110,30,40,0.14); }}
    .kpi-card .kpi-label {{ font-size: 0.68rem; color: var(--sub); font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }}
    .kpi-card .kpi-value {{ font-size: 1.45rem; font-weight: 700; color: var(--brand-maroon); margin: 4px 0; }}
    .kpi-card .kpi-delta {{ font-size: 0.72rem; font-weight: 500; }}
    .kpi-card .kpi-delta.pos {{ color: #00B050; }}
    .kpi-card .kpi-delta.neg {{ color: var(--neg); }}

    /* ── Charts grid ── */
    .charts-grid {{
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 18px;
      margin-bottom: 22px;
    }}
    .charts-grid.one-col {{ grid-template-columns: 1fr; }}
    .chart-card {{
      background: var(--card-bg);
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.07);
      overflow: hidden;
    }}
    .chart-card .chart-title {{
      background: var(--brand-maroon);
      color: #fff;
      padding: 9px 16px;
      font-size: 0.78rem;
      font-weight: 600;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }}
    .chart-card .chart-note {{
      font-size: 0.62rem;
      opacity: 0.8;
      font-style: italic;
    }}
    .chart-card .chart-body {{ padding: 14px; position: relative; }}

    /* ── Table ── */
    .table-card {{
      background: var(--card-bg);
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.07);
      margin-bottom: 22px;
      overflow: hidden;
    }}
    .table-header {{
      background: var(--brand-maroon);
      color: #fff;
      padding: 10px 18px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 0.82rem;
      font-weight: 600;
    }}
    .table-wrapper {{ overflow-x: auto; max-height: 380px; overflow-y: auto; }}
    table {{ width: 100%; border-collapse: collapse; font-size: 0.75rem; }}
    thead th {{
      background: var(--cream);
      color: var(--brand-maroon);
      padding: 8px 10px;
      text-align: right;
      font-weight: 700;
      position: sticky;
      top: 0;
      cursor: pointer;
      user-select: none;
      border-bottom: 2px solid var(--brand-maroon);
      white-space: nowrap;
    }}
    thead th:first-child {{ text-align: left; }}
    thead th:hover {{ background: #f0e6e8; }}
    thead th .sort-icon {{ margin-left: 4px; opacity: 0.5; }}
    tbody tr {{ transition: background 0.12s; }}
    tbody tr:nth-child(even) {{ background: #FAFAFA; }}
    tbody tr:hover {{ background: var(--cream); }}
    tbody td {{ padding: 6px 10px; text-align: right; border-bottom: 1px solid #F0F0F0; }}
    tbody td:first-child {{ text-align: left; }}
    .neg-val {{ color: var(--neg); font-weight: 600; }}

    /* ── Opportunities ── */
    .opp-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: 14px;
      margin-bottom: 22px;
    }}
    .opp-card {{
      background: var(--card-bg);
      border-radius: 10px;
      padding: 14px 16px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.07);
      border-top: 4px solid;
    }}
    .opp-card.riesgo {{ border-color: var(--neg); }}
    .opp-card.oportunidad {{ border-color: #00B050; }}
    .opp-card.informacion {{ border-color: #FFC000; }}
    .opp-tipo {{ font-size: 0.65rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.8px; margin-bottom: 4px; }}
    .opp-tipo.riesgo {{ color: var(--neg); }}
    .opp-tipo.oportunidad {{ color: #00B050; }}
    .opp-tipo.informacion {{ color: #FFC000; }}
    .opp-hallazgo {{ font-size: 0.78rem; font-weight: 600; margin-bottom: 6px; }}
    .opp-impacto {{ font-size: 0.7rem; color: var(--sub); margin-bottom: 4px; }}
    .opp-rec {{ font-size: 0.72rem; border-top: 1px solid #EEE; padding-top: 6px; margin-top: 4px; }}

    /* ── Footer ── */
    footer {{
      text-align: center;
      padding: 16px;
      font-size: 0.68rem;
      color: var(--sub);
      border-top: 1px solid #E8E8E8;
    }}

    /* ── Pagination ── */
    .pagination {{
      display: flex;
      gap: 8px;
      align-items: center;
      justify-content: flex-end;
      padding: 10px 18px;
      font-size: 0.75rem;
    }}
    .page-info {{ color: var(--sub); }}

    @media (max-width: 800px) {{
      .charts-grid {{ grid-template-columns: 1fr; }}
      header {{ flex-direction: column; gap: 8px; text-align: center; }}
      .filter-bar {{ padding: 10px 16px; }}
      main {{ padding: 14px 16px; }}
    }}
  </style>
</head>
<body>

<header>
  <div>
    <h1>Dashboard · Ventas y Margen</h1>
    <div class="subtitle" id="headerSubtitle">Cargando...</div>
  </div>
  <div class="logo-area">
    {logo_svg if logo_svg else '<div class="logo-fallback">LOCO<span>TEQUILA</span></div>'}
  </div>
</header>

<div class="filter-bar">
  <div class="filter-group">
    <label>Año</label>
    <select id="fAnio"><option value="all">Todos</option></select>
  </div>
  <div class="filter-group">
    <label>Semana</label>
    <select id="fSemana"><option value="all">Todas</option></select>
  </div>
  <div class="filter-group">
    <label>Producto</label>
    <select id="fProducto"><option value="all">Todos</option></select>
  </div>
  <div class="filter-group">
    <label>Canal</label>
    <select id="fCanal"><option value="all">Todos</option></select>
  </div>
  <div class="filter-group">
    <label>Estado</label>
    <select id="fEstado"><option value="all">Todos</option></select>
  </div>
  <div class="filter-group">
    <label>Buscar cliente</label>
    <input type="text" id="fCliente" placeholder="Nombre cliente...">
  </div>
  <button class="btn btn-primary" onclick="applyFilters()">Aplicar</button>
  <button class="btn btn-secondary" onclick="resetFilters()">Limpiar</button>
  <button class="btn btn-secondary" onclick="downloadCSV()">⬇ Descargar CSV</button>
</div>

<main>
  <!-- KPIs -->
  <div class="kpi-grid" id="kpiGrid"></div>

  <!-- Charts row 1 -->
  <div class="charts-grid">
    <div class="chart-card">
      <div class="chart-title">
        Ventas Netas Semanales ($MXN sin IVA)
        <span class="chart-note">Las ventas no incluyen IVA, IEPS</span>
      </div>
      <div class="chart-body"><canvas id="chartSemanal" height="160"></canvas></div>
    </div>
    <div class="chart-card">
      <div class="chart-title">
        Ventas por Producto — Últimas 26 Semanas
        <span class="chart-note">Barras apiladas sin IVA</span>
      </div>
      <div class="chart-body"><canvas id="chartProducto" height="160"></canvas></div>
    </div>
  </div>

  <!-- Charts row 2 -->
  <div class="charts-grid">
    <div class="chart-card">
      <div class="chart-title">Ranking de Productos — YTD</div>
      <div class="chart-body"><canvas id="chartRanking" height="130"></canvas></div>
    </div>
    <div class="chart-card">
      <div class="chart-title">Top Regiones por Ventas — YTD</div>
      <div class="chart-body"><canvas id="chartRegional" height="130"></canvas></div>
    </div>
  </div>

  <!-- Charts row 3: Canal -->
  <div class="charts-grid one-col">
    <div class="chart-card">
      <div class="chart-title">
        Ventas por Canal — Últimas 26 Semanas
        <span class="chart-note">Sin IVA</span>
      </div>
      <div class="chart-body"><canvas id="chartCanal" height="110"></canvas></div>
    </div>
  </div>

  <!-- Tabla filtrable -->
  <div class="table-card">
    <div class="table-header">
      <span>Detalle de Ventas (año actual)</span>
      <span id="tableCount" style="font-size:0.72rem;opacity:0.8;"></span>
    </div>
    <div class="table-wrapper">
      <table id="mainTable">
        <thead>
          <tr>
            <th onclick="sortTable(0)">Semana <span class="sort-icon">⇅</span></th>
            <th onclick="sortTable(1)">Producto <span class="sort-icon">⇅</span></th>
            <th onclick="sortTable(2)">Canal <span class="sort-icon">⇅</span></th>
            <th onclick="sortTable(3)">Estado <span class="sort-icon">⇅</span></th>
            <th onclick="sortTable(4)">Cliente <span class="sort-icon">⇅</span></th>
            <th onclick="sortTable(5)">Ventas $ <span class="sort-icon">⇅</span></th>
            <th onclick="sortTable(6)">Botellas <span class="sort-icon">⇅</span></th>
            <th onclick="sortTable(7)">Margen % <span class="sort-icon">⇅</span></th>
          </tr>
        </thead>
        <tbody id="tableBody"></tbody>
      </table>
    </div>
    <div class="pagination">
      <span class="page-info" id="pageInfo"></span>
      <button class="btn btn-secondary" onclick="prevPage()">‹ Ant</button>
      <button class="btn btn-secondary" onclick="nextPage()">Sig ›</button>
    </div>
  </div>

  <!-- Oportunidades y Riesgos -->
  <div class="chart-card" style="margin-bottom:22px;">
    <div class="chart-title">Oportunidades y Riesgos Identificados</div>
    <div class="chart-body">
      <div class="opp-grid" id="oppGrid"></div>
    </div>
  </div>
</main>

<footer>
  Loco Tequila · Dirección de Finanzas · Las ventas no incluyen IVA ni IEPS · Generado automáticamente
</footer>

<script>
// ── Datos embebidos ──────────────────────────────────────────────────────
const DATA = {data_json};

// ── Estado ───────────────────────────────────────────────────────────────
let filteredTabla = [...DATA.tabla];
let sortCol = -1, sortAsc = true;
let page = 1;
const PAGE_SIZE = 50;

// ── Inicialización ───────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {{
  document.getElementById('headerSubtitle').textContent =
    `${{DATA.meta.semana_label}} · Dashboard Ejecutivo`;

  populateFilters();
  renderKPIs(DATA.kpis);
  renderCharts(DATA.serie_semanal, DATA.ranking, DATA.regional);
  renderTable(filteredTabla);
  renderOportunidades(DATA.oportunidades);
}});

// ── Filtros ───────────────────────────────────────────────────────────────
function populateFilters() {{
  const add = (id, items) => {{
    const sel = document.getElementById(id);
    items.forEach(v => {{
      const o = document.createElement('option');
      o.value = v; o.textContent = v; sel.appendChild(o);
    }});
  }};
  add('fAnio',     DATA.filtros.anios);
  add('fSemana',   DATA.filtros.semanas.map(s => `W${{String(s).padStart(2,'0')}}`));
  add('fProducto', DATA.filtros.productos);
  add('fCanal',    DATA.filtros.canales);
  add('fEstado',   DATA.filtros.estados);
}}

function applyFilters() {{
  const anio     = document.getElementById('fAnio').value;
  const semana   = document.getElementById('fSemana').value;
  const producto = document.getElementById('fProducto').value;
  const canal    = document.getElementById('fCanal').value;
  const estado   = document.getElementById('fEstado').value;
  const cliente  = document.getElementById('fCliente').value.toLowerCase().trim();

  filteredTabla = DATA.tabla.filter(r => {{
    if (anio    !== 'all' && String(r.semana).slice(0,4) !== String(anio)) return false;
    if (semana  !== 'all' && !r.semana.endsWith(semana.replace('W','W'))) return false;
    if (producto !== 'all' && r.producto_display !== producto) return false;
    if (canal   !== 'all' && r.canal !== canal) return false;
    if (estado  !== 'all' && r.estado !== estado) return false;
    if (cliente && !r.cliente.toLowerCase().includes(cliente)) return false;
    return true;
  }});

  page = 1;
  renderTable(filteredTabla);
}}

function resetFilters() {{
  ['fAnio','fSemana','fProducto','fCanal','fEstado'].forEach(id => {{
    document.getElementById(id).value = 'all';
  }});
  document.getElementById('fCliente').value = '';
  filteredTabla = [...DATA.tabla];
  page = 1;
  renderTable(filteredTabla);
}}

// ── KPIs ──────────────────────────────────────────────────────────────────
function renderKPIs(k) {{
  const grid = document.getElementById('kpiGrid');
  const cards = [
    {{ label: 'Ventas Netas (sem.)', value: fmtCur(k.ventas_netas),
       delta: k.vs_plan_pct, deltaLabel: 'vs Plan' }},
    {{ label: 'Plan Semanal', value: fmtCur(k.plan), delta: null }},
    {{ label: 'WoW', value: `${{k.vs_semana_ant_pct >= 0 ? '+' : ''}}${{k.vs_semana_ant_pct.toFixed(1)}}%`,
       delta: k.vs_semana_ant_pct, deltaLabel: 'vs sem. ant.' }},
    {{ label: 'vs Año Anterior', value: `${{k.vs_anio_ant_pct >= 0 ? '+' : ''}}${{k.vs_anio_ant_pct.toFixed(1)}}%`,
       delta: k.vs_anio_ant_pct, deltaLabel: 'misma semana LY' }},
    {{ label: 'YTD Ventas', value: fmtCur(k.ytd),
       delta: k.ytd_vs_ly_pct, deltaLabel: 'vs YTD LY' }},
    {{ label: '# Botellas', value: fmtInt(k.botellas), delta: null }},
    {{ label: 'Margen %', value: `${{k.margen_pct.toFixed(1)}}%`, delta: null }},
    {{ label: 'Ticket Promedio', value: `$${{k.ticket.toFixed(1)}}`, delta: null }},
  ];
  grid.innerHTML = cards.map(c => `
    <div class="kpi-card">
      <div class="kpi-label">${{c.label}}</div>
      <div class="kpi-value">${{c.value}}</div>
      ${{c.delta !== null
        ? `<div class="kpi-delta ${{c.delta >= 0 ? 'pos' : 'neg'}}">
             ${{c.delta >= 0 ? '▲' : '▼'}} ${{Math.abs(c.delta).toFixed(1)}}% ${{c.deltaLabel || ''}}
           </div>`
        : '<div class="kpi-delta"> </div>'
      }}
    </div>
  `).join('');
}}

// ── Charts ────────────────────────────────────────────────────────────────
let charts = {{}};

function renderCharts(serie, ranking, regional) {{
  // 1. Ventas semanales + plan
  if (charts.semanal) charts.semanal.destroy();
  charts.semanal = new Chart(document.getElementById('chartSemanal'), {{
    type: 'bar',
    data: {{
      labels: serie.labels,
      datasets: [
        {{
          label: 'Ventas Netas $',
          data: serie.totales,
          backgroundColor: '{BRAND_MAROON}CC',
          borderColor: '{BRAND_MAROON}',
          borderWidth: 1,
          order: 2,
        }},
        {{
          label: 'Plan $',
          data: serie.plan,
          type: 'line',
          borderColor: '{CHART_PLAN_LINE}',
          backgroundColor: 'transparent',
          borderWidth: 2,
          pointRadius: 3,
          tension: 0.3,
          order: 1,
        }},
      ]
    }},
    options: chartOptions('$MXN miles (sin IVA)', true),
  }});

  // 2. Barras apiladas por producto
  if (charts.producto) charts.producto.destroy();
  const prodDatasets = Object.entries(serie.por_producto).map(([name, vals]) => ({{
    label: name,
    data: vals,
    backgroundColor: DATA.product_colors[name] || '#999',
    stack: 'prod',
  }}));
  charts.producto = new Chart(document.getElementById('chartProducto'), {{
    type: 'bar',
    data: {{ labels: serie.labels, datasets: prodDatasets }},
    options: chartOptions('$MXN miles (sin IVA)', false),
  }});

  // 3. Ranking productos (barras horizontales — NO dona)
  if (charts.ranking) charts.ranking.destroy();
  charts.ranking = new Chart(document.getElementById('chartRanking'), {{
    type: 'bar',
    data: {{
      labels: ranking.labels,
      datasets: [{{
        label: 'Ventas YTD',
        data: ranking.ventas,
        backgroundColor: ranking.colors,
        borderRadius: 4,
      }}]
    }},
    options: {{
      indexAxis: 'y',
      responsive: true,
      plugins: {{
        legend: {{ display: false }},
        tooltip: {{ callbacks: {{ label: ctx => ' ' + fmtCur(ctx.raw) }} }},
      }},
      scales: {{
        x: {{
          ticks: {{ callback: v => fmtMillions(v), font: {{size: 10}} }},
          grid: {{ color: '{CHART_GRID}' }},
        }},
        y: {{ ticks: {{ font: {{size: 10}} }} }},
      }}
    }}
  }});

  // 4. Top regional (barras horizontales)
  if (charts.regional) charts.regional.destroy();
  charts.regional = new Chart(document.getElementById('chartRegional'), {{
    type: 'bar',
    data: {{
      labels: regional.labels,
      datasets: [{{
        label: 'Ventas YTD',
        data: regional.ventas,
        backgroundColor: '{BRAND_MAROON}BB',
        borderRadius: 3,
      }}]
    }},
    options: {{
      indexAxis: 'y',
      responsive: true,
      plugins: {{
        legend: {{ display: false }},
        tooltip: {{ callbacks: {{ label: ctx => ' ' + fmtCur(ctx.raw) }} }},
      }},
      scales: {{
        x: {{
          ticks: {{ callback: v => fmtMillions(v), font: {{size: 10}} }},
          grid: {{ color: '{CHART_GRID}' }},
        }},
        y: {{ ticks: {{ font: {{size: 9}} }} }},
      }}
    }}
  }});

  // 5. Canal
  if (charts.canal) charts.canal.destroy();
  const canalDatasets = Object.entries(serie.por_canal).map(([name, vals]) => ({{
    label: name,
    data: vals,
    backgroundColor: DATA.canal_colors[name] || '#999',
    stack: 'canal',
  }}));
  charts.canal = new Chart(document.getElementById('chartCanal'), {{
    type: 'bar',
    data: {{ labels: serie.labels, datasets: canalDatasets }},
    options: chartOptions('$MXN miles (sin IVA)', false),
  }});
}}

function chartOptions(yLabel, showPlan) {{
  return {{
    responsive: true,
    interaction: {{ mode: 'index', intersect: false }},
    plugins: {{
      legend: {{ position: 'bottom', labels: {{ font: {{size: 10}}, boxWidth: 12 }} }},
      tooltip: {{
        callbacks: {{
          label: ctx => ` ${{ctx.dataset.label}}: ${{fmtCur(ctx.raw)}}`
        }}
      }}
    }},
    scales: {{
      x: {{
        stacked: true,
        ticks: {{ font: {{size: 9}}, maxRotation: 40 }},
        grid: {{ display: false }},
      }},
      y: {{
        stacked: true,
        ticks: {{ callback: v => fmtMillions(v), font: {{size: 10}} }},
        grid: {{ color: '{CHART_GRID}' }},
        title: {{ display: true, text: yLabel, font: {{size: 10}} }},
      }}
    }}
  }};
}}

// ── Tabla ─────────────────────────────────────────────────────────────────
function renderTable(data) {{
  const tbody = document.getElementById('tableBody');
  const start = (page - 1) * PAGE_SIZE;
  const slice = data.slice(start, start + PAGE_SIZE);

  tbody.innerHTML = slice.map(r => `
    <tr>
      <td>${{r.semana}}</td>
      <td>${{r.producto_display || r.producto}}</td>
      <td>${{r.canal}}</td>
      <td>${{r.estado}}</td>
      <td>${{r.cliente || '—'}}</td>
      <td>${{fmtCur(r.venta_sin_iva)}}</td>
      <td>${{fmtInt(r.botellas)}}</td>
      <td class="${{r.margen_pct < 0 ? 'neg-val' : ''}}">${{r.margen_pct.toFixed(1)}}%</td>
    </tr>
  `).join('');

  const total = data.length;
  const end   = Math.min(start + PAGE_SIZE, total);
  document.getElementById('tableCount').textContent = `${{total.toLocaleString()}} registros`;
  document.getElementById('pageInfo').textContent =
    `${{start + 1}}–${{end}} de ${{total}}`;
}}

function sortTable(col) {{
  if (sortCol === col) sortAsc = !sortAsc;
  else {{ sortCol = col; sortAsc = true; }}
  const keys = ['semana','producto_display','canal','estado','cliente',
                 'venta_sin_iva','botellas','margen_pct'];
  const key = keys[col];
  filteredTabla.sort((a, b) => {{
    const va = a[key] ?? ''; const vb = b[key] ?? '';
    if (typeof va === 'number') return sortAsc ? va - vb : vb - va;
    return sortAsc ? String(va).localeCompare(String(vb))
                   : String(vb).localeCompare(String(va));
  }});
  page = 1;
  renderTable(filteredTabla);
}}

function prevPage() {{ if (page > 1) {{ page--; renderTable(filteredTabla); }} }}
function nextPage() {{
  const max = Math.ceil(filteredTabla.length / PAGE_SIZE);
  if (page < max) {{ page++; renderTable(filteredTabla); }}
}}

// ── Oportunidades ─────────────────────────────────────────────────────────
function renderOportunidades(items) {{
  const grid = document.getElementById('oppGrid');
  grid.innerHTML = items.map(item => {{
    const cls = item.tipo.toLowerCase().normalize('NFD').replace(/[\\u0300-\\u036f]/g,'');
    return `
      <div class="opp-card ${{cls}}">
        <div class="opp-tipo ${{cls}}">${{item.tipo}}</div>
        <div class="opp-hallazgo">${{item.hallazgo}}</div>
        <div class="opp-impacto">📊 Impacto: ${{item.impacto}}</div>
        <div class="opp-rec">💡 ${{item.recomendacion}}</div>
      </div>
    `;
  }}).join('');
}}

// ── Descarga CSV ─────────────────────────────────────────────────────────
function downloadCSV() {{
  const cols = ['semana','producto_display','canal','estado','cliente',
                'venta_sin_iva','botellas','margen_pct'];
  const hdr  = ['Semana','Producto','Canal','Estado','Cliente',
                 'Venta Sin IVA','Botellas','Margen %'];
  let csv = hdr.join(',') + '\\n';
  filteredTabla.forEach(r => {{
    csv += cols.map(k => {{
      const v = r[k] ?? '';
      return typeof v === 'string' && v.includes(',') ? `"${{v}}"` : v;
    }}).join(',') + '\\n';
  }});
  const blob = new Blob([csv], {{type: 'text/csv;charset=utf-8;'}});
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a'); a.href = url;
  a.download = `loco_tequila_ventas_semana${{DATA.meta.semana}}_${{DATA.meta.anio}}.csv`;
  a.click(); URL.revokeObjectURL(url);
}}

// ── Helpers de formato ────────────────────────────────────────────────────
function fmtCur(v) {{
  if (v == null || isNaN(v)) return '$0';
  return '$' + Math.round(v).toLocaleString('es-MX');
}}
function fmtInt(v) {{
  if (v == null || isNaN(v)) return '0';
  return Math.round(v).toLocaleString('es-MX');
}}
function fmtMillions(v) {{
  if (Math.abs(v) >= 1e6) return '$' + (v/1e6).toFixed(1) + 'M';
  if (Math.abs(v) >= 1e3) return '$' + (v/1e3).toFixed(0) + 'k';
  return '$' + v;
}}
</script>
</body>
</html>
"""


# ---------------------------------------------------------------------------
# Función de entrada
# ---------------------------------------------------------------------------

def generate_dashboard(processor: LocoDataProcessor, output_path: str,
                       logo_path: Optional[str] = None):
    """Genera el dashboard HTML y lo guarda en output_path."""
    print("[HTML] Preparando datos...")
    data = _prepare_data(processor)

    # Logo blanco inline para el header
    logo_svg = ""
    svg_source = logo_path
    if svg_source is None:
        # Buscar en assets/ relativo al script
        candidate = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "assets", "Loco_Tequila_Logo.svg"
        )
        if os.path.exists(candidate):
            svg_source = candidate
    if svg_source:
        try:
            logo_svg = get_logo_for_html(svg_source, mode="inline")
        except Exception as e:
            print(f"[HTML] Logo no pudo cargarse: {e}")

    print("[HTML] Construyendo HTML...")
    html = _build_html(data, logo_svg=logo_svg)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"[HTML] Guardado: {output_path}")
