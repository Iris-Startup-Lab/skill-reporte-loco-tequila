# Skill: Generador de Reportes Ejecutivos Semanales (Loco Tequila)

Esta **Skill** proporciona un sistema agnóstico y automatizado para la generación de reportes ejecutivos de ventas y margen a partir de datos transaccionales y de planificación en formato CSV.

Produce tres entregables profesionales optimizados para la toma de decisiones directivas:

1. **Reporte PDF Ejecutivo (~30 páginas)**: Diseñado según principios de visualización directiva (*Storytelling with Data*), paleta de color institucional (Maroon), gráficos vectoriales de tendencia y logo institucional integrado.
2. **Libro Excel (XLSX, 6-8 Hojas Analíticas)**: Hojas analíticas con formato condicional, semáforos WoW/MoM/YoY/Plan, desglose por producto, cliente y región, hojas de comparativos personalizados y contexto de mercado.
3. **Dashboard HTML Interactivo**: Panel responsivo con filtros dinámicos por año, semana, producto, canal, estado y cliente, con gráficos Chart.js y descarga de datos filtrados en CSV.

---

## 🌟 Arquitectura Agnóstica y Estándar de Agent Skills

La skill cumple estrictamente con el estándar universal de **Agent Skills** (definido en `SKILL.md`), permitiendo que cualquier agente de Inteligencia Artificial comprenda las instrucciones, argumentos y herramientas necesarias para ejecutar el pipeline de forma autónoma.

### 🤝 Protocolo de Bienvenida y Manejo de Datos de Entrada
Cuando el usuario activa la Skill o interactúa con el agente sin adjuntar datos:
1. **Presentación Automática**: El agente saluda y explica los entregables (PDF, XLSX, Dashboard HTML).
2. **Validación de Archivos**: Verifica si existen archivos CSV de entrada (`loco_actuals_enriquecido.csv`, `loco_plan.csv`).
3. **Manejo Faltante / Simulación**: Si el usuario no ha subido archivos, el agente ofrece amablemente procesar los **datos de prueba y simulación** en `data_for_test_and_simulation/` (Semana 30, 2026).
4. **Guía de Opciones**: Ofrece menú interactivo para reporte completo, entregables individuales, comparativos personalizados (WoW, MoM, YoY) o inclusión de contexto de mercado tequilero (CRT, Agave, NOM-006).

### Modelos Recomendados por Entorno

* **Claude Desktop**:
  * Claude Sonnet (Recomendado)
  * Claude Opus
* **Antigravity / Google DeepMind Agentic IDE**:
  * Gemini 3.1 Pro
  * Gemini 3.1 Flash / Ultra
* **OpenCode / CLI Agents**:
  * DeepSeek V4 Pro
  * Kimi 3

---

## 🚀 Requisitos e Instalación del Entorno Local (Conda)

Para la ejecución local de los scripts de generación y procesamiento gráfico, se requiere **Python 3.10+** y dependencias nativas (Cairo para renderizado SVG a PNG de alta definición).

### 1. Creación y Activación del Ambiente Conda

En PowerShell (Windows):

```powershell
# Iniciar hook de Conda en PowerShell
& "E:\Users\1167486\AppData\Local\anaconda3\Scripts\conda.exe" shell.powershell hook | Out-String | Invoke-Expression

# Activar el entorno 'data_analytics_science'
conda activate data_analytics_science
```

### 2. Instalación de Dependencias

```powershell
# Dependencias de renderizado vectorial nativo (requerido para el logo SVG/PNG)
conda install -c conda-forge cairo pycairo -y

# Dependencias de Python para procesamiento y reportes
pip install cairosvg reportlab openpyxl pandas numpy matplotlib svglib chardet
```

---

## ⚙️ Modos de Uso y Comandos CLI

El orquestador principal es `scripts/generate_report.py`.

### 1. Generación de Reporte Semanal Completo

```powershell
python scripts/generate_report.py --semana 30 --anio 2026 `
    --datos-dir data_for_test_and_simulation `
    --output-dir output
```

### 2. Generación por Artefacto Individual

```powershell
# Generar únicamente el PDF
python scripts/generate_report.py --semana 30 --anio 2026 --solo pdf

# Generar únicamente el Excel XLSX
python scripts/generate_report.py --semana 30 --anio 2026 --solo xlsx

# Generar únicamente el Dashboard HTML
python scripts/generate_report.py --semana 30 --anio 2026 --solo html
```

### 3. Comparativos Custom (Semana vs Semana, Mes vs Mes, Año vs Año)

```powershell
# Comparar Semana 30 vs Semana 25 de 2026
python scripts/generate_report.py --semana 30 --anio 2026 --solo xlsx `
    --modo-comparar semana --comparar-semana 25 --comparar-anio 2026

# Comparar Julio (Mes 7) vs Mayo (Mes 5) de 2026
python scripts/generate_report.py --semana 30 --anio 2026 --solo xlsx `
    --modo-comparar mes --comparar-mes 5 --comparar-anio 2026

# Comparar Año 2026 vs Año 2025 (YTD)
python scripts/generate_report.py --semana 30 --anio 2026 --solo xlsx `
    --modo-comparar anio --comparar-anio 2025
```

### 4. Integración de Contexto de Mercado (CRT, Agave, NOM-006)

```powershell
# 1. Ver queries sugeridas para búsqueda web
python scripts/generate_report.py --semana 30 --anio 2026 --mostrar-queries-mercado

# 2. Generar el archivo template de contexto
python scripts/generate_report.py --semana 30 --anio 2026 --generar-template-mercado

# 3. Llenar el template generado y ejecutar el reporte con contexto incluido
python scripts/generate_report.py --semana 30 --anio 2026 `
    --contexto-mercado output/template_contexto_mercado_S30_2026.txt
```

---

## 🛠️ Cómo Integrar y Probar la Skill en Distintos Entornos de IA

### A. Claude Desktop

1. Configura tu servidor MCP de sistema de archivos o terminal (ej. `@modelcontextprotocol/server-filesystem`).
2. Agrega la carpeta del proyecto a las rutas permitidas o incluye el contenido de `SKILL.md` en el Project Knowledge / Prompt del sistema.
3. Al interactuar con **Claude Sonnet** o **Claude Opus**, pídele acciones como:
   > *"Genera el reporte semanal de la semana 30 de 2026 en formato PDF y Excel"*
4. El modelo leerá las instrucciones de `SKILL.md`, identificará la estructura del CLI y ejecutará las llamadas mediante la terminal o scripts de Python en tu ambiente conda.

### B. OpenCode

1. Abre la carpeta del proyecto en OpenCode.
2. Selecciona cualquiera de los modelos compatibles (**DeepSeek V4 Pro** o **Kimi 3**).
3. La especificación en `SKILL.md` será detectada automáticamente.
4. Puedes dar instrucciones en lenguaje natural:
   > *"Compara las ventas del mes de julio contra mayo de 2026 y genera la hoja ejecutiva de Excel"*
5. OpenCode activará el ambiente conda (`conda activate data_analytics_science`) y ejecutará el comando con `--modo-comparar mes --comparar-mes 5`.

### C. Antigravity (Google DeepMind Agentic IDE)

1. Antigravity auto-descubre las habilidades presentes en la raíz de trabajo o dentro de `.agents/skills/`.
2. Con **Gemini 3.1 Pro** o **Gemini 3.1 Flash**, el agente coordinará automáticamente herramientas como `search_web` para recopilar datos sobre el sector tequilero (estadísticas CRT, precios de materia prima de Agave y regulaciones de la NOM-006) y generará el reporte final integrado.

---

## 📁 Estructura del Proyecto

```
skill_reporte/
├── README.md                      <- Documentación principal del proyecto y setup (Este archivo)
├── SKILL.md                       <- Especificación estándar de la Skill para Agentes IA
├── designs/
│   ├── Design.md                  <- Sistema de diseño (paleta, tokens y layout)
│   └── storytelling_summary.md    <- Resumen por capítulos de Storytelling with Data
├── assets/
│   ├── Loco_Tequila_Logo.svg      <- Logo SVG original institucional
│   ├── Loco_Tequila_Logo_white.svg<- Logo SVG en versión blanca automatizada
│   └── Loco_Tequila_Logo_white.png<- Logo PNG renderizado de alta definición para PDF
├── data_for_test_and_simulation/  <- CSVs de datos de entrada (ventas y plan)
├── scripts/
│   ├── generate_report.py         <- CLI Orquestador Principal
│   ├── data_processor.py          <- Motor de cálculo de KPIs, agregaciones y comparativos
│   ├── logo_processor.py          <- Módulo de transformación y renderizado del logo
│   ├── pdf_generator.py           <- Generador de reporte PDF (~30 págs) con ReportLab
│   ├── xlsx_generator.py          <- Generador de libro Excel ejecutivo con openpyxl
│   ├── dashboard_generator.py     <- Generador de Dashboard HTML responsivo
│   └── market_context.py          <- Módulo de procesamiento y plantillas de mercado
└── output/                        <- Carpeta donde se guardan los artefactos generados
```
