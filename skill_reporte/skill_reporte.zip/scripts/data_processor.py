"""
data_processor.py
=================
Carga, limpia y transforma los CSVs de ventas de Loco Tequila.
Produce DataFrames listos para los generadores de PDF, XLSX y HTML.

Columnas clave del CSV actuals_enriquecido:
  semana de venta, fecha de venta, SKU/producto, unidades_de_venta,
  categoria_o_linea, cliente, canal, region_o_estado, precio_unitario,
  venta_con_impuestos, venta_sin_impuestos, anio, ml_botella, botellas,
  litros, cajas_9L, margen_pct, margen_pesos, sub_canal, canal_reporte

Columnas clave del CSV actual_vs_plan_semanal:
  anio, semana de venta, fecha_lunes, SKU/producto, canal, canal_reporte,
  plan_unidades, plan_botellas, plan_cajas_9L, plan_venta_sin_impuestos,
  plan_venta_con_impuestos, plan_margen_pesos, actual_unidades, actual_botellas,
  actual_cajas_9L, actual_venta_sin, actual_venta_con, actual_margen,
  var_vs_plan_$, var_vs_plan_%, cumplimiento_%
"""

import os
import re
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Optional, Dict, Tuple

from design_tokens import (
    PRODUCT_ORDER, PRODUCT_DISPLAY_NAMES, CANAL_ORDER, CANAL_MAPPING
)


# ---------------------------------------------------------------------------
# Helpers de carga
# ---------------------------------------------------------------------------

def _detect_encoding(filepath: str) -> str:
    """Detecta encoding del archivo usando chardet; fallback a latin-1."""
    try:
        import chardet
        with open(filepath, "rb") as f:
            result = chardet.detect(f.read(50_000))
        enc = result.get("encoding") or "latin-1"
        # chardet a veces devuelve 'windows-1252' que pandas acepta
        return enc
    except ImportError:
        return "latin-1"


def _load_csv(filepath: str) -> pd.DataFrame:
    """Carga un CSV con detección automática de encoding."""
    enc = _detect_encoding(filepath)
    try:
        df = pd.read_csv(filepath, encoding=enc, low_memory=False)
    except UnicodeDecodeError:
        df = pd.read_csv(filepath, encoding="latin-1", low_memory=False)
    return df


def _load_table(filepath: str) -> pd.DataFrame:
    """Carga un CSV o XLSX con detección automática de encoding y selección inteligente de hoja."""
    if not filepath or not os.path.exists(filepath):
        return pd.DataFrame()
    if filepath.lower().endswith(".xlsx") or filepath.lower().endswith(".xls"):
        try:
            import openpyxl
            wb = openpyxl.load_workbook(filepath, read_only=True)
            sheets = wb.sheetnames
            target_sheet = sheets[0]
            for s in sheets:
                s_low = s.lower()
                if "clean" in s_low or "hoja1" in s_low or "bdd" in s_low or "resumen" in s_low or "data" in s_low:
                    target_sheet = s
                    break
            return pd.read_excel(filepath, sheet_name=target_sheet)
        except Exception:
            return pd.read_excel(filepath)
    else:
        return _load_csv(filepath)


EXPANDED_PRODUCT_MAPPING = {
    "Loco Blanco":  "Loco Blanco",
    "Puro Corazon": "Puro Corazon",
    "Puro Corazón": "Puro Corazon",
    "Loco Ambar":   "Loco Ambar",
    "Loco Ámbar":   "Loco Ambar",
    "Loco 269":     "Loco 269",
    "loco 269":     "Loco 269",
    "Loco Aureo":   "Loco Aureo",
    "Loco Áureo":   "Loco Aureo",
    "Loco 200":     "Loco 200",
    "Loco 200 ml":  "Loco 200",
    "Loco 200 ML":  "Loco 200",
    "Loco Áureo Elevacion": "Loco Aureo",
    "Loco Aureo Elevacion": "Loco Aureo",
    "Vap Loco Blanco (2 copas)": "Loco Blanco",
    "Vap Loco Ambar (2 copas)": "Loco Ambar",
    "Vap Puro Corazon (2 copas)": "Puro Corazon",
    "Loco Ambar (Vap caja piel)": "Loco Ambar",
    "LOCO TEQUILA BLANCO 750 ML": "Loco Blanco",
    "LOCO TEQUILA BLANCO 200 ML": "Loco 200",
    "LOCO TEQUILA REPOSADO ÁMBAR 750 ML": "Loco Ambar",
    "LOCO TEQUILA REPOSADO AMBAR 750 ML": "Loco Ambar",
    "LOCO TEQUILA PURO CORAZÓN 750 ML": "Puro Corazon",
    "LOCO TEQUILA PURO CORAZON 750 ML": "Puro Corazon",
    "LOCO TEQUILA AÑEJO ÁUREO 750 ML": "Loco Aureo",
    "LOCO TEQUILA ANEJO AUREO 750 ML": "Loco Aureo",
    "TEQ LOCO EDICION ESPECIAL 2026": "Loco 269",
    "TEQ LOCO PURO COR D MUERTOS 25 750M": "Puro Corazon",
    "TEQ LOCO PURO COR MURCIELAGO 750ML": "Puro Corazon",
    "TEQ LOCO PURO COR SERPIENTE 750ML": "Puro Corazon",
    "TEQ LOCO PURO CORAZON COYOTE 750ML": "Puro Corazon",
    "TEQ LOCO PURO CORAZON COLIBRI 750ML": "Puro Corazon",
    "TEQ LOCO PURO CORAZON X ANIV 750ML": "Puro Corazon",
    "VAP LOCO TEQUILA BLANCO 750 ML": "Loco Blanco",
    "VAP LOCO TEQUILA BLANCO 750 ML ": "Loco Blanco",
    "VAP LOCO TEQUILA REPOSADO ÁMBAR 750 ML": "Loco Ambar",
    "VAP LOCO TEQUILA REPOSADO AMBAR 750 ML": "Loco Ambar",
    "VAP LOCO TEQUILA 2026": "Loco 269",
}


def _normalize_product(name: str) -> str:
    """Normaliza nombres de producto a las claves canónicas."""
    s = str(name).strip()
    return EXPANDED_PRODUCT_MAPPING.get(s, s)


def _normalize_canal(canal: str) -> str:
    """Normaliza canal al nombre canónico de reporte."""
    canal = str(canal).strip()
    return CANAL_MAPPING.get(canal, canal)


def _infer_sub_canal(canal_norm: str, cliente: str) -> str:
    if canal_norm != "Off Trade":
        return str(canal_norm)
    cli = str(cliente).lower()
    moderno_keywords = ["liverpool", "palacio", "walmart", "soriana", "chedraui", "costco", "sams", "city market", "superama", "fresko"]
    if any(k in cli for k in moderno_keywords):
        return "Moderno"
    return "Tradicional"


def _infer_categoria(producto: str) -> str:
    cat_map = {
        "Loco Blanco": "Blanco",
        "Puro Corazon": "Puro Corazón",
        "Loco Ambar": "Ámbar",
        "Loco 269": "Blanco",
        "Loco Aureo": "Áureo",
        "Loco 200": "Blanco",
    }
    return cat_map.get(producto, "Blanco")


def _week_str(year: int, week: int) -> str:
    return f"{year}-W{week:02d}"


def _prev_week(year: int, week: int) -> Tuple[int, int]:
    if week == 1:
        return year - 1, 52
    return year, week - 1


def _same_week_prev_year(year: int, week: int) -> Tuple[int, int]:
    return year - 1, week


# ---------------------------------------------------------------------------
# Clase principal
# ---------------------------------------------------------------------------

class LocoDataProcessor:
    """
    Carga los datos y expone DataFrames listos para cada sección del reporte.

    Parámetros
    ----------
    datos_dir   : carpeta con los CSVs o XLSXs
    semana      : número de semana ISO (1-52)
    anio        : año del reporte
    n_top_clientes : número de clientes top para desglose
    """

    def __init__(
        self,
        datos_dir: str,
        semana: int,
        anio: int,
        n_top_clientes: int = 6,
    ):
        self.datos_dir = datos_dir
        self.semana = semana
        self.anio = anio
        self.n_top_clientes = n_top_clientes

        self._load_data()
        self._enrich()

    # ------------------------------------------------------------------
    # Carga y enriquecimiento
    # ------------------------------------------------------------------

    def _load_data(self):
        actuals_path = os.path.join(self.datos_dir, "loco_actuals_enriquecido.csv")
        plan_path    = os.path.join(self.datos_dir, "loco_actual_vs_plan_semanal.csv")

        # Fallback inteligente si no existe con el nombre exacto
        if os.path.isdir(self.datos_dir):
            all_files = [
                os.path.join(self.datos_dir, f) for f in os.listdir(self.datos_dir)
                if f.lower().endswith(".csv") or f.lower().endswith(".xlsx")
            ]

            if not os.path.exists(actuals_path):
                for c in all_files:
                    c_name = os.path.basename(c).lower()
                    if ("actual" in c_name or "venta" in c_name or "enriquecido" in c_name or "reporte" in c_name) and "plan" not in c_name and "presupuesto" not in c_name:
                        actuals_path = c
                        break
                else:
                    if all_files:
                        actuals_path = all_files[0]

            if not os.path.exists(plan_path):
                for c in all_files:
                    c_name = os.path.basename(c).lower()
                    if "plan" in c_name or "presupuesto" in c_name or "vs_plan" in c_name or "semanalizado" in c_name:
                        plan_path = c
                        break

        self.df_actuals = _load_table(actuals_path)
        self.df_plan    = _load_table(plan_path) if os.path.exists(plan_path) else pd.DataFrame()

    def _enrich(self):
        df = self.df_actuals.copy()
        if df.empty:
            self.df = df
            self.dfp = self.df_plan.copy()
            return

        # 1. Filtrar registros cancelados si existe columna de Estatus
        estatus_cols = [c for c in df.columns if "estatus" in c.lower() or "status" in c.lower()]
        if estatus_cols:
            c_est = estatus_cols[0]
            df = df[df[c_est].astype(str).str.strip().str.lower() != "cancelado"].copy()

        # 2. Fecha y Año
        fecha_cols = [c for c in df.columns if c in ["fecha de venta", "Fecha de Emisión", "Fecha de Emision", "fecha", "Fecha"]]
        if fecha_cols and "fecha de venta" not in df.columns:
            df["fecha de venta"] = df[fecha_cols[0]]

        if "fecha de venta" in df.columns:
            df["fecha"] = pd.to_datetime(df["fecha de venta"], errors="coerce")
        else:
            df["fecha"] = pd.to_datetime(pd.Series([f"{self.anio}-01-01"] * len(df)))

        df["mes"] = df["fecha"].dt.month.fillna(1).astype(int)
        df["mes_nombre"] = df["fecha"].dt.strftime("%b/%y")

        if "anio" in df.columns:
            df["anio_num"] = pd.to_numeric(df["anio"], errors="coerce").fillna(self.anio).astype("Int64")
        elif df["fecha"].notna().any():
            df["anio_num"] = df["fecha"].dt.year.fillna(self.anio).astype("Int64")
            df["anio"] = df["anio_num"]
        else:
            df["anio_num"] = pd.Series(self.anio, index=df.index).astype("Int64")
            df["anio"] = self.anio

        # 3. Semana de venta
        if "semana de venta" not in df.columns:
            sem_cols = [c for c in df.columns if c.lower() in ["semana", "semana_num", "week"]]
            if sem_cols:
                sem_col = sem_cols[0]
                def _parse_sem_val(val, yr):
                    s = str(val).strip()
                    nums = re.findall(r"\d+", s)
                    if nums:
                        w_int = int(nums[-1])
                        return f"{yr}-W{w_int:02d}"
                    return f"{yr}-W01"
                df["semana de venta"] = [
                    _parse_sem_val(v, y if pd.notna(y) else self.anio)
                    for v, y in zip(df[sem_col], df["anio_num"])
                ]
            elif df["fecha"].notna().any():
                df["semana de venta"] = df["fecha"].dt.strftime("%G-W%V")
            else:
                df["semana de venta"] = f"{self.anio}-W{self.semana:02d}"

        df["semana_str"] = df["semana de venta"].astype(str).str.strip()
        df["semana_num"] = (
            df["semana_str"]
            .str.extract(r"W(\d+)")[0]
            .astype(float)
            .astype("Int64")
        )
        if df["semana_num"].isna().any():
            df["semana_num"] = df["semana_num"].fillna(df["fecha"].dt.isocalendar().week).astype("Int64")

        # 4. SKU / Producto
        if "SKU/producto" not in df.columns:
            sku_cols = [c for c in df.columns if c in ["SKU", "ARTÍCULO", "Articulo", "producto", "Producto", "articulo"]]
            if sku_cols:
                df["SKU/producto"] = df[sku_cols[0]]
            else:
                df["SKU/producto"] = "Loco Blanco"

        df["producto"] = df["SKU/producto"].apply(_normalize_product)

        # 5. Canal y Canal de Reporte
        if "canal_reporte" not in df.columns:
            can_cols = [c for c in df.columns if c in ["Canal / Reporte", "canal", "Canal", "CANAL"]]
            if can_cols:
                df["canal_reporte"] = df[can_cols[0]]
            else:
                df["canal_reporte"] = "Off Trade"

        if "canal" not in df.columns:
            df["canal"] = df["canal_reporte"]

        df["canal_norm"] = df["canal_reporte"].apply(_normalize_canal)

        # 6. Cliente
        if "cliente" not in df.columns:
            cli_cols = [c for c in df.columns if c in ["Cliente", "CLIENTE", "Receptor", "receptor", "cliente_nombre"]]
            if cli_cols:
                df["cliente"] = df[cli_cols[0]].fillna("Público en General")
            else:
                df["cliente"] = "Público en General"

        # 7. Región o Estado
        if "region_o_estado" not in df.columns:
            reg_cols = [c for c in df.columns if c in ["Ubicación", "Ubicacion", "ubicacion", "REGIÓN", "Region", "region", "estado", "Estado"]]
            if reg_cols:
                df["region_o_estado"] = df[reg_cols[0]].fillna("Nacional")
            else:
                df["region_o_estado"] = "Nacional"

        df["region_o_estado"] = df["region_o_estado"].astype(str).str.strip().replace({
            "Quetetaro": "Queretaro",
            "Cava Sautto": "Guanajuato",
        })

        # 8. Unidades / Botellas
        if "botellas" not in df.columns:
            unit_cols = [c for c in df.columns if c in ["Unidades", "unidades", "unidades_de_venta", "UNIDADES", "cantidad", "Cantidad"]]
            if unit_cols:
                df["botellas"] = pd.to_numeric(df[unit_cols[0]], errors="coerce").fillna(0)
            else:
                df["botellas"] = 0

        if "unidades_de_venta" not in df.columns:
            df["unidades_de_venta"] = df["botellas"]

        # 9. Precios y Ventas
        if "precio_unitario" not in df.columns:
            imp_cols = [c for c in df.columns if c in ["Importe", "importe", "PRECIO / BOT", "precio", "Precio"]]
            if imp_cols:
                df["precio_unitario"] = pd.to_numeric(df[imp_cols[0]], errors="coerce").fillna(0)
            else:
                df["precio_unitario"] = 0

        if "venta_sin_impuestos" not in df.columns:
            vta_cols = [c for c in df.columns if c in ["Venta", "venta", "VENTA NETA (MXN)", "venta_neta", "subtotal", "Subtotal"]]
            if vta_cols:
                df["venta_sin_impuestos"] = pd.to_numeric(df[vta_cols[0]], errors="coerce").fillna(0)
            else:
                df["venta_sin_impuestos"] = df["botellas"] * df["precio_unitario"]

        if "venta_con_impuestos" not in df.columns:
            monto_cols = [c for c in df.columns if c in ["Monto", "monto", "Venta + IVA", "total", "Total"]]
            if monto_cols:
                df["venta_con_impuestos"] = pd.to_numeric(df[monto_cols[0]], errors="coerce").fillna(0)
            else:
                df["venta_con_impuestos"] = df["venta_sin_impuestos"] * 1.53

        # 10. Volumetría: ml_botella, litros, cajas_9L
        if "ml_botella" not in df.columns:
            df["ml_botella"] = df["SKU/producto"].apply(lambda s: 200 if "200" in str(s) else 750)
        if "litros" not in df.columns:
            df["litros"] = df["botellas"] * df["ml_botella"] / 1000.0
        if "cajas_9L" not in df.columns:
            df["cajas_9L"] = df["litros"] / 9.0

        # 11. Sub-canal
        if "sub_canal" not in df.columns:
            df["sub_canal"] = df.apply(lambda r: _infer_sub_canal(r.get("canal_norm"), r.get("cliente")), axis=1)

        # 12. Categoría o línea
        if "categoria_o_linea" not in df.columns:
            df["categoria_o_linea"] = df["producto"].apply(_infer_categoria)

        # 13. Margen
        if "margen_pesos" not in df.columns or df["margen_pesos"].sum() == 0:
            cogs_map = {}
            if not self.df_plan.empty and "COGS" in self.df_plan.columns:
                try:
                    dfp_temp = self.df_plan.copy()
                    if "ARTÍCULO" in dfp_temp.columns:
                        dfp_temp["_p"] = dfp_temp["ARTÍCULO"].apply(_normalize_product)
                    elif "SKU/producto" in dfp_temp.columns:
                        dfp_temp["_p"] = dfp_temp["SKU/producto"].apply(_normalize_product)
                    else:
                        dfp_temp["_p"] = "Loco Blanco"
                    cogs_map = dfp_temp[dfp_temp["COGS"] > 0].groupby("_p")["COGS"].mean().to_dict()
                except Exception:
                    cogs_map = {}

            if cogs_map:
                cogs_unit = df["producto"].map(cogs_map).fillna(450.0)
                df["margen_pesos"] = df["venta_sin_impuestos"] - (df["botellas"] * cogs_unit)
                df["margen_pct"] = np.where(df["venta_sin_impuestos"] > 0, df["margen_pesos"] / df["venta_sin_impuestos"] * 100, 60.0)
            else:
                df["margen_pct"] = 60.0
                df["margen_pesos"] = df["venta_sin_impuestos"] * 0.60

        # Numéricos
        for col in ["venta_sin_impuestos", "venta_con_impuestos",
                    "margen_pesos", "botellas", "cajas_9L",
                    "margen_pct", "precio_unitario"]:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

        self.df = df

        # --------------------------------------------------------------
        # Plan
        # --------------------------------------------------------------
        dfp = self.df_plan.copy()
        if not dfp.empty:
            # SKU
            if "SKU/producto" not in dfp.columns:
                art_cols = [c for c in dfp.columns if "art" in c.lower()]
                if art_cols:
                    dfp["SKU/producto"] = dfp[art_cols[0]]
                elif "producto" in dfp.columns:
                    dfp["SKU/producto"] = dfp["producto"]
                else:
                    dfp["SKU/producto"] = "Loco Blanco"

            dfp["producto"] = dfp["SKU/producto"].apply(_normalize_product)

            # Canal
            if "canal_reporte" not in dfp.columns:
                can_cols = [c for c in dfp.columns if "canal" in c.lower()]
                if can_cols:
                    dfp["canal_reporte"] = dfp[can_cols[0]]
                else:
                    dfp["canal_reporte"] = "Off Trade"

            dfp["canal_norm"] = dfp["canal_reporte"].apply(_normalize_canal)

            # Año: si no tiene año, asumir año concurrente (self.anio)
            if "anio" in dfp.columns:
                dfp["anio_num"] = pd.to_numeric(dfp["anio"], errors="coerce").fillna(self.anio).astype("Int64")
            else:
                dfp["anio_num"] = pd.Series(self.anio, index=dfp.index).astype("Int64")
                dfp["anio"] = self.anio

            # Semana
            if "semana de venta" not in dfp.columns:
                sem_cols = [c for c in dfp.columns if "semana" in c.lower()]
                if sem_cols:
                    def _parse_plan_sem(val, yr):
                        nums = re.findall(r"\d+", str(val))
                        if nums:
                            return f"{yr}-W{int(nums[-1]):02d}"
                        return f"{yr}-W01"
                    dfp["semana de venta"] = [
                        _parse_plan_sem(v, y if pd.notna(y) else self.anio)
                        for v, y in zip(dfp[sem_cols[0]], dfp["anio_num"])
                    ]
                else:
                    dfp["semana de venta"] = f"{self.anio}-W{self.semana:02d}"

            dfp["semana_str"] = dfp["semana de venta"].astype(str).str.strip()
            dfp["semana_num"] = (
                dfp["semana_str"]
                .str.extract(r"W(\d+)")[0]
                .astype(float)
                .astype("Int64")
            )

            # Unidades / Botellas
            if "plan_botellas" not in dfp.columns:
                unit_cols = [c for c in dfp.columns if "unidad" in c.lower() or "botella" in c.lower()]
                if unit_cols:
                    dfp["plan_botellas"] = pd.to_numeric(dfp[unit_cols[0]], errors="coerce").fillna(0)
                else:
                    dfp["plan_botellas"] = 0
            if "plan_unidades" not in dfp.columns:
                dfp["plan_unidades"] = dfp["plan_botellas"]

            # Ventas sin impuestos
            if "plan_venta_sin_impuestos" not in dfp.columns:
                vta_cols = [c for c in dfp.columns if "venta neta" in c.lower() or "plan_venta" in c.lower() or "venta_sin" in c.lower()]
                if vta_cols:
                    dfp["plan_venta_sin_impuestos"] = pd.to_numeric(dfp[vta_cols[0]], errors="coerce").fillna(0)
                else:
                    dfp["plan_venta_sin_impuestos"] = 0

            # Margen en pesos
            if "plan_margen_pesos" not in dfp.columns:
                cogs_cols = [c for c in dfp.columns if "cogs total" in c.lower() or "costo total" in c.lower()]
                if cogs_cols:
                    cogs_tot = pd.to_numeric(dfp[cogs_cols[0]], errors="coerce").fillna(0)
                    dfp["plan_margen_pesos"] = dfp["plan_venta_sin_impuestos"] - cogs_tot
                else:
                    dfp["plan_margen_pesos"] = dfp["plan_venta_sin_impuestos"] * 0.60

            # Cajas 9L
            if "plan_cajas_9L" not in dfp.columns:
                ml = dfp["SKU/producto"].apply(lambda s: 200 if "200" in str(s) else 750)
                dfp["plan_cajas_9L"] = dfp["plan_botellas"] * ml / 9000.0

            for col in ["plan_venta_sin_impuestos", "plan_venta_con_impuestos",
                        "plan_margen_pesos", "plan_botellas", "plan_cajas_9L"]:
                if col in dfp.columns:
                    dfp[col] = pd.to_numeric(dfp[col], errors="coerce").fillna(0)

        self.dfp = dfp

    # ------------------------------------------------------------------
    # Filtros de periodo
    # ------------------------------------------------------------------

    def _filter_period(self, year: int, week: int) -> pd.DataFrame:
        df = self.df
        return df[(df["anio_num"] == year) & (df["semana_num"] == week)]

    def _filter_year(self, year: int) -> pd.DataFrame:
        return self.df[self.df["anio_num"] == year]

    def _filter_ytd(self, year: int, max_week: int) -> pd.DataFrame:
        df = self.df
        return df[(df["anio_num"] == year) & (df["semana_num"] <= max_week)]

    def _filter_month(self, year: int, month: int) -> pd.DataFrame:
        df = self.df
        return df[(df["anio_num"] == year) & (df["mes"] == month)]

    # ------------------------------------------------------------------
    # KPIs por periodo
    # ------------------------------------------------------------------

    def _kpis(self, df: pd.DataFrame) -> Dict:
        ventas = df["venta_sin_impuestos"].sum()
        botellas = df["botellas"].sum()
        cajas = df["cajas_9L"].sum()
        margen = df["margen_pesos"].sum()
        margen_pct = (margen / ventas * 100) if ventas > 0 else 0
        ticket = (ventas / botellas) if botellas > 0 else 0
        return {
            "ventas_netas": ventas,
            "botellas": botellas,
            "cajas_9l": cajas,
            "margen_pesos": margen,
            "margen_pct": margen_pct,
            "ticket_promedio": ticket,
        }

    def _plan_kpis(self, year: int, week: int) -> Dict:
        dfp = self.dfp
        p = dfp[(dfp["anio_num"] == year) & (dfp["semana_num"] == week)]
        ventas = p["plan_venta_sin_impuestos"].sum()
        botellas = p["plan_botellas"].sum()
        margen = p["plan_margen_pesos"].sum()
        return {
            "ventas_netas": ventas,
            "botellas": botellas,
            "cajas_9l": p["plan_cajas_9L"].sum(),
            "margen_pesos": margen,
            # Simétrico con _kpis: permite comparar todas las métricas vs plan
            "margen_pct": (margen / ventas * 100) if ventas > 0 else 0,
            "ticket_promedio": (ventas / botellas) if botellas > 0 else 0,
        }

    # ------------------------------------------------------------------
    # Público: Resumen ejecutivo
    # ------------------------------------------------------------------

    def get_resumen_ejecutivo(self) -> Dict:
        """KPIs actuales + variaciones WoW, MoM, YoY, YTD."""
        y, w = self.anio, self.semana
        py, pw = _prev_week(y, w)
        ly, lyw = _same_week_prev_year(y, w)

        cur  = self._kpis(self._filter_period(y, w))
        prev = self._kpis(self._filter_period(py, pw))
        lasty= self._kpis(self._filter_period(ly, lyw))
        plan = self._plan_kpis(y, w)

        # Mes actual
        cur_fecha = self._filter_period(y, w)["fecha"].min()
        if pd.isna(cur_fecha):
            cur_mes = 1
        else:
            cur_mes = cur_fecha.month
        mes_act  = self._kpis(self._filter_month(y, cur_mes))
        mes_prev = self._kpis(self._filter_month(y, cur_mes - 1 if cur_mes > 1 else 12))
        mes_ly   = self._kpis(self._filter_month(ly, cur_mes))

        ytd_cur  = self._kpis(self._filter_ytd(y, w))
        ytd_prev = self._kpis(self._filter_ytd(ly, lyw))

        def var(a, b, key="ventas_netas"):
            va, vb = a.get(key, 0), b.get(key, 0)
            d = va - vb
            p = (d / vb * 100) if vb != 0 else (100.0 if va > 0 else 0.0)
            return {"abs": d, "pct": p}

        return {
            "semana": w,
            "anio": y,
            "actual": cur,
            "plan": plan,
            # KPIs completos de cada periodo de referencia — permiten construir
            # comparativas por métrica (no solo ventas) en Excel y PDF.
            "semana_anterior": prev,
            "anio_anterior": lasty,
            "vs_plan": var(cur, plan),
            "vs_semana_anterior": var(cur, prev),
            "vs_anio_anterior": var(cur, lasty),
            "mes_actual": mes_act,
            "mes_vs_anterior": var(mes_act, mes_prev),
            "mes_vs_ly": var(mes_act, mes_ly),
            "ytd_actual": ytd_cur,
            "ytd_vs_ly": var(ytd_cur, ytd_prev),
        }

    # ------------------------------------------------------------------
    # Público: Tabla resumen canal × producto
    # ------------------------------------------------------------------

    def get_matriz_canal_producto(self, mode: str = "semanal") -> pd.DataFrame:
        """
        Retorna DataFrame pivotado Canal × Producto con ventas sin IVA.
        mode: 'semanal' | 'anual'
        """
        y, w = self.anio, self.semana
        if mode == "semanal":
            df = self._filter_period(y, w)
        else:
            df = self._filter_ytd(y, w)

        piv = (
            df.groupby(["canal_norm", "producto"])["venta_sin_impuestos"]
            .sum()
            .unstack(fill_value=0)
        )
        # Asegurar columnas en orden canónico
        for p in PRODUCT_ORDER:
            if p not in piv.columns:
                piv[p] = 0
        piv = piv.reindex(columns=PRODUCT_ORDER, fill_value=0)

        # Asegurar filas en orden canónico
        for c in CANAL_ORDER:
            if c not in piv.index:
                piv.loc[c] = 0
        piv = piv.reindex(CANAL_ORDER, fill_value=0)

        piv["Total"] = piv.sum(axis=1)
        totals = piv.sum(axis=0)
        totals.name = "Total"
        piv = pd.concat([piv, totals.to_frame().T])
        return piv

    # ------------------------------------------------------------------
    # Público: Top clientes
    # ------------------------------------------------------------------

    def get_top_clientes(self, mode: str = "anual") -> list:
        """Retorna lista de los N clientes con mayor venta en el periodo."""
        y, w = self.anio, self.semana
        if mode == "semanal":
            df = self._filter_period(y, w)
        else:
            df = self._filter_ytd(y, w)

        top = (
            df.groupby("cliente")["venta_sin_impuestos"]
            .sum()
            .nlargest(self.n_top_clientes)
            .index.tolist()
        )
        return top

    def get_detalle_clientes(self, clientes: list, mode: str = "anual") -> pd.DataFrame:
        """Tabla producto × cliente para los clientes indicados."""
        y, w = self.anio, self.semana
        if mode == "semanal":
            df = self._filter_period(y, w)
        else:
            df = self._filter_ytd(y, w)

        df_top = df[df["cliente"].isin(clientes)]
        piv = (
            df_top.groupby(["cliente", "producto"])["venta_sin_impuestos"]
            .sum()
            .unstack(fill_value=0)
        )
        for p in PRODUCT_ORDER:
            if p not in piv.columns:
                piv[p] = 0
        piv = piv.reindex(columns=PRODUCT_ORDER, fill_value=0)
        piv["Total"] = piv.sum(axis=1)
        piv = piv.sort_values("Total", ascending=False)
        return piv

    # ------------------------------------------------------------------
    # Público: Histórico mensual (para gráfica de barras apiladas + línea)
    # ------------------------------------------------------------------

    def get_historico_mensual(self) -> pd.DataFrame:
        """
        DataFrame: index = (año, mes), columnas = productos + Total.
        Solo incluye meses hasta la semana actual del año corriente.
        """
        y, w = self.anio, self.semana
        cur_fecha = self._filter_period(y, w)["fecha"].min()
        if pd.isna(cur_fecha):
            cur_mes = 12
        else:
            cur_mes = cur_fecha.month

        df_hist = self.df[
            ((self.df["anio_num"] == y - 1)) |
            ((self.df["anio_num"] == y) & (self.df["mes"] <= cur_mes))
        ]

        piv = (
            df_hist.groupby(["anio_num", "mes", "producto"])["venta_sin_impuestos"]
            .sum()
            .unstack(fill_value=0)
        )
        for p in PRODUCT_ORDER:
            if p not in piv.columns:
                piv[p] = 0
        piv = piv.reindex(columns=PRODUCT_ORDER, fill_value=0)
        piv["Total"] = piv.sum(axis=1)
        piv = piv.reset_index()
        piv["label"] = piv.apply(
            lambda r: datetime(int(r["anio_num"]), int(r["mes"]), 1).strftime("%b/%y"), axis=1
        )
        return piv

    # ------------------------------------------------------------------
    # Público: Serie semanal (8-12 semanas) para gráficas combo SKU/canal
    # ------------------------------------------------------------------

    def get_serie_semanal(
        self,
        n_semanas: int = 12,
        group_by: str = "producto",  # 'producto' | 'canal'
        filtro: Optional[str] = None,
    ) -> pd.DataFrame:
        """
        Retorna ventas semanales de las últimas n_semanas.
        Si filtro != None, filtra por el producto o canal indicado.
        Garantiza que siempre retorne exactamente n_semanas filas en orden cronológico.
        """
        y, w = self.anio, self.semana

        # Construir lista de (year, week) hacia atrás
        periodos = []
        cy, cw = y, w
        for _ in range(n_semanas):
            periodos.append((cy, cw))
            cy, cw = _prev_week(cy, cw)

        periodos = list(reversed(periodos))
        base_df = pd.DataFrame(periodos, columns=["anio_num", "semana_num"])
        base_df["label"] = base_df["semana_num"].apply(lambda x: f"W{int(x):02d}")

        # Filtrar datos
        cond = pd.Series(False, index=self.df.index)
        for ay, aw in periodos:
            cond |= (self.df["anio_num"] == ay) & (self.df["semana_num"] == aw)
        df_sub = self.df[cond].copy()

        if filtro and group_by == "producto":
            df_sub = df_sub[df_sub["producto"] == filtro]
        elif filtro and group_by == "canal":
            df_sub = df_sub[df_sub["canal_norm"] == filtro]

        group_col = "producto" if group_by == "producto" else "canal_norm"

        if not df_sub.empty:
            piv = (
                df_sub.groupby(["anio_num", "semana_num", group_col])["venta_sin_impuestos"]
                .sum()
                .unstack(fill_value=0)
            )
            piv["Total"] = piv.sum(axis=1)
            piv = piv.reset_index()
            result = pd.merge(base_df, piv, on=["anio_num", "semana_num"], how="left").fillna(0)
        else:
            result = base_df.copy()
            if filtro:
                result[filtro] = 0.0
            result["Total"] = 0.0

        return result

    def get_serie_semanal_botellas(
        self,
        n_semanas: int = 12,
        group_by: str = "producto",
        filtro: Optional[str] = None,
    ) -> pd.DataFrame:
        """Igual que get_serie_semanal pero en botellas."""
        y, w = self.anio, self.semana
        periodos = []
        cy, cw = y, w
        for _ in range(n_semanas):
            periodos.append((cy, cw))
            cy, cw = _prev_week(cy, cw)
        periodos = list(reversed(periodos))

        base_df = pd.DataFrame(periodos, columns=["anio_num", "semana_num"])
        base_df["label"] = base_df["semana_num"].apply(lambda x: f"W{int(x):02d}")

        cond = pd.Series(False, index=self.df.index)
        for ay, aw in periodos:
            cond |= (self.df["anio_num"] == ay) & (self.df["semana_num"] == aw)
        df_sub = self.df[cond].copy()

        if filtro and group_by == "producto":
            df_sub = df_sub[df_sub["producto"] == filtro]
        elif filtro and group_by == "canal":
            df_sub = df_sub[df_sub["canal_norm"] == filtro]

        group_col = "producto" if group_by == "producto" else "canal_norm"

        if not df_sub.empty:
            piv = (
                df_sub.groupby(["anio_num", "semana_num", group_col])["botellas"]
                .sum()
                .unstack(fill_value=0)
            )
            piv["Total"] = piv.sum(axis=1)
            piv = piv.reset_index()
            result = pd.merge(base_df, piv, on=["anio_num", "semana_num"], how="left").fillna(0)
        else:
            result = base_df.copy()
            if filtro:
                result[filtro] = 0.0
            result["Total"] = 0.0

        return result

    def get_plan_semanal(
        self,
        n_semanas: int = 12,
        filtro_producto: Optional[str] = None,
        filtro_canal: Optional[str] = None,
    ) -> pd.DataFrame:
        """Plan semanal de ventas sin IVA para las últimas n semanas."""
        y, w = self.anio, self.semana
        periodos = []
        cy, cw = y, w
        for _ in range(n_semanas):
            periodos.append((cy, cw))
            cy, cw = _prev_week(cy, cw)
        periodos = list(reversed(periodos))

        base_df = pd.DataFrame(periodos, columns=["anio_num", "semana_num"])
        base_df["label"] = base_df["semana_num"].apply(lambda x: f"W{int(x):02d}")

        if not self.dfp.empty:
            cond = pd.Series(False, index=self.dfp.index)
            for ay, aw in periodos:
                cond |= (self.dfp["anio_num"] == ay) & (self.dfp["semana_num"] == aw)
            dfp_sub = self.dfp[cond].copy()

            if filtro_producto:
                dfp_sub = dfp_sub[dfp_sub["producto"] == filtro_producto]
            if filtro_canal:
                dfp_sub = dfp_sub[dfp_sub["canal_norm"] == filtro_canal]

            if not dfp_sub.empty:
                agg = dfp_sub.groupby(["anio_num", "semana_num"])["plan_venta_sin_impuestos"].sum().reset_index()
                result = pd.merge(base_df, agg, on=["anio_num", "semana_num"], how="left").fillna(0)
            else:
                result = base_df.copy()
                result["plan_venta_sin_impuestos"] = 0.0
        else:
            result = base_df.copy()
            result["plan_venta_sin_impuestos"] = 0.0

        return result

    # ------------------------------------------------------------------
    # Público: Tabla comparativa WoW / MoM / YoY
    # ------------------------------------------------------------------

    def get_tabla_comparativa(self) -> Dict:
        """Retorna dict con todas las comparaciones de periodo."""
        return self.get_resumen_ejecutivo()

    # ------------------------------------------------------------------
    # Público: Análisis por producto (ranking + tendencia)
    # ------------------------------------------------------------------

    def get_ranking_productos(self, mode: str = "anual") -> pd.DataFrame:
        y, w = self.anio, self.semana
        if mode == "semanal":
            df = self._filter_period(y, w)
        else:
            df = self._filter_ytd(y, w)

        agg = (
            df.groupby("producto")
            .agg(
                ventas=("venta_sin_impuestos", "sum"),
                botellas=("botellas", "sum"),
                cajas=("cajas_9L", "sum"),
                margen=("margen_pesos", "sum"),
            )
            .reset_index()
        )
        agg["margen_pct"] = (agg["margen"] / agg["ventas"] * 100).fillna(0)
        agg["participacion_pct"] = (agg["ventas"] / agg["ventas"].sum() * 100).fillna(0)
        agg["producto_display"] = agg["producto"].map(PRODUCT_DISPLAY_NAMES).fillna(agg["producto"])

        # Orden canónico
        cat = pd.CategoricalDtype(PRODUCT_ORDER, ordered=True)
        agg["producto_cat"] = agg["producto"].astype(cat)
        agg = agg.sort_values("producto_cat").drop(columns=["producto_cat"])
        return agg

    # ------------------------------------------------------------------
    # Público: Análisis regional
    # ------------------------------------------------------------------

    def get_analisis_regional(self, mode: str = "anual") -> pd.DataFrame:
        y, w = self.anio, self.semana
        if mode == "semanal":
            df = self._filter_period(y, w)
        else:
            df = self._filter_ytd(y, w)

        agg = (
            df.groupby("region_o_estado")
            .agg(
                ventas=("venta_sin_impuestos", "sum"),
                botellas=("botellas", "sum"),
            )
            .reset_index()
            .sort_values("ventas", ascending=False)
        )
        agg["participacion_pct"] = (agg["ventas"] / agg["ventas"].sum() * 100).fillna(0)
        return agg

    # ------------------------------------------------------------------
    # Público: Tabla SKU × periodo (para páginas individuales del PDF)
    # ------------------------------------------------------------------

    def get_tabla_sku(self, producto: str) -> Dict:
        """
        Retorna KPIs de un SKU para: semana actual, semana anterior,
        año anterior (misma semana), plan, YTD, YTD año anterior.
        """
        y, w = self.anio, self.semana
        py, pw = _prev_week(y, w)
        ly, lyw = _same_week_prev_year(y, w)

        def kpis_sku(dfq):
            dfs = dfq[dfq["producto"] == producto]
            v = dfs["venta_sin_impuestos"].sum()
            b = dfs["botellas"].sum()
            c = dfs["cajas_9L"].sum()
            m = dfs["margen_pesos"].sum()
            mp = (m / v * 100) if v > 0 else 0
            t = (v / b) if b > 0 else 0
            return {"ventas": v, "botellas": b, "cajas": c,
                    "margen_pesos": m, "margen_pct": mp, "ticket": t}

        cur   = kpis_sku(self._filter_period(y, w))
        prev  = kpis_sku(self._filter_period(py, pw))
        lasty = kpis_sku(self._filter_period(ly, lyw))
        ytd   = kpis_sku(self._filter_ytd(y, w))
        ytd_ly= kpis_sku(self._filter_ytd(ly, lyw))

        # Plan semanal del SKU
        dfp_sku = self.dfp[
            (self.dfp["anio_num"] == y) &
            (self.dfp["semana_num"] == w) &
            (self.dfp["producto"] == producto)
        ]
        plan_v = dfp_sku["plan_venta_sin_impuestos"].sum()
        plan_b = dfp_sku["plan_botellas"].sum()
        plan_c = dfp_sku["plan_cajas_9L"].sum() if "plan_cajas_9L" in dfp_sku.columns else 0
        plan_m = dfp_sku["plan_margen_pesos"].sum() if "plan_margen_pesos" in dfp_sku.columns else 0

        return {
            "producto": producto,
            "semana_actual": cur,
            "semana_anterior": prev,
            "anio_anterior": lasty,
            "plan": {
                "ventas": plan_v,
                "botellas": plan_b,
                "cajas": plan_c,
                "margen_pesos": plan_m,
                "margen_pct": (plan_m / plan_v * 100) if plan_v > 0 else 0,
                "ticket": (plan_v / plan_b) if plan_b > 0 else 0,
            },
            "ytd": ytd,
            "ytd_anio_anterior": ytd_ly,
        }

    # ------------------------------------------------------------------
    # Público: Oportunidades y riesgos (análisis automático)
    # ------------------------------------------------------------------

    def get_oportunidades_riesgos(self) -> list:
        """
        Genera lista automática de hallazgos: tipo, descripción, impacto, recomendación.
        """
        resumen = self.get_resumen_ejecutivo()
        rankings = self.get_ranking_productos("anual")
        items = []

        # WoW
        wow = resumen["vs_semana_anterior"]
        if wow["pct"] < -10:
            items.append({
                "hallazgo": f"Caída semanal del {abs(wow['pct']):.0f}% vs semana anterior",
                "tipo": "Riesgo",
                "impacto": f"${abs(wow['abs']):,.0f} MXN sin IVA",
                "recomendacion": "Revisar causa raíz: cliente, producto o región con mayor caída",
            })
        elif wow["pct"] > 10:
            items.append({
                "hallazgo": f"Crecimiento semanal del {wow['pct']:.0f}% vs semana anterior",
                "tipo": "Oportunidad",
                "impacto": f"${wow['abs']:,.0f} MXN adicionales",
                "recomendacion": "Identificar driver y replicar en otras regiones/canales",
            })

        # vs Plan
        vp = resumen["vs_plan"]
        if vp["pct"] < -5:
            items.append({
                "hallazgo": f"Ventas {abs(vp['pct']):.0f}% por debajo del plan",
                "tipo": "Riesgo",
                "impacto": f"${abs(vp['abs']):,.0f} MXN de brecha vs plan",
                "recomendacion": "Activar plan de recuperación en canales de mayor gap",
            })

        # YTD vs año anterior
        ytd_var = resumen["ytd_vs_ly"]
        if ytd_var["pct"] > 5:
            items.append({
                "hallazgo": f"YTD crece {ytd_var['pct']:.0f}% vs mismo período año anterior",
                "tipo": "Oportunidad",
                "impacto": f"${ytd_var['abs']:,.0f} MXN acumulados adicionales",
                "recomendacion": "Sostener ritmo; monitorear capacidad operativa",
            })
        elif ytd_var["pct"] < -5:
            items.append({
                "hallazgo": f"YTD cae {abs(ytd_var['pct']):.0f}% vs mismo período año anterior",
                "tipo": "Riesgo",
                "impacto": f"${abs(ytd_var['abs']):,.0f} MXN menos que el año anterior",
                "recomendacion": "Revisar estrategia de precio y mix de canal",
            })

        # Concentración de productos
        if not rankings.empty:
            top1 = rankings.iloc[0]
            if top1["participacion_pct"] > 50:
                items.append({
                    "hallazgo": f"{PRODUCT_DISPLAY_NAMES.get(top1['producto'], top1['producto'])} concentra "
                                f"{top1['participacion_pct']:.0f}% de las ventas",
                    "tipo": "Riesgo",
                    "impacto": "Alta dependencia de un solo SKU",
                    "recomendacion": "Diversificar mix impulsando Loco Ámbar y Loco Áureo",
                })

        # Si hay pocos hallazgos, agregar nota de mercado
        if len(items) < 3:
            items.append({
                "hallazgo": "Contexto de mercado no disponible en datos internos",
                "tipo": "Información",
                "impacto": "N/D",
                "recomendacion": "Complementar con datos de exportaciones CRT y precio de agave",
            })

        return items[:6]  # máximo 6 hallazgos

    # ------------------------------------------------------------------
    # Público: DataFrame completo para dashboard HTML
    # ------------------------------------------------------------------

    def get_dataframe_dashboard(self) -> pd.DataFrame:
        """Retorna el DataFrame enriquecido completo para el dashboard."""
        cols = [
            "semana_str", "fecha", "producto", "canal_norm",
            "cliente", "region_o_estado", "mes",
            "venta_sin_impuestos", "botellas", "cajas_9L",
            "margen_pesos", "margen_pct", "precio_unitario",
            "anio_num", "semana_num",
        ]
        df_out = self.df[cols].copy()
        df_out.columns = [
            "semana", "fecha", "producto", "canal",
            "cliente", "estado", "mes",
            "venta_sin_iva", "botellas", "cajas_9l",
            "margen_pesos", "margen_pct", "precio_unitario",
            "anio", "semana_num",
        ]
        df_out["producto_display"] = df_out["producto"].map(PRODUCT_DISPLAY_NAMES).fillna(df_out["producto"])
        return df_out

    # ------------------------------------------------------------------
    # Público: Comparativo custom entre dos periodos arbitrarios
    # ------------------------------------------------------------------

    def get_comparativo_custom(
        self,
        modo: str,              # 'semana' | 'mes' | 'anio'
        periodo_a: Dict,        # {'semana':30,'anio':2026} | {'mes':6,'anio':2026} | {'anio':2026}
        periodo_b: Dict,        # mismo esquema
    ) -> Dict:
        """
        Compara dos periodos arbitrarios y retorna un dict con:
          - kpis_a, kpis_b: métricas de cada periodo
          - variacion: diferencias absolutas y porcentuales
          - por_producto: DataFrame comparativo por SKU
          - por_canal: DataFrame comparativo por canal
          - por_cliente: DataFrame comparativo por cliente
          - labels: {'a': 'Semana 30-2026', 'b': 'Semana 25-2026'}

        modo = 'semana' : compara semanas ISO individuales
        modo = 'mes'    : compara meses completos
        modo = 'anio'   : compara años completos
        """
        # Filtrar periodo A
        df_a = self._filter_by_periodo(modo, periodo_a)
        df_b = self._filter_by_periodo(modo, periodo_b)

        kpis_a = self._kpis(df_a)
        kpis_b = self._kpis(df_b)

        # Variaciones
        def var(a_val, b_val):
            d = a_val - b_val
            p = (d / b_val * 100) if b_val != 0 else (100.0 if a_val > 0 else 0.0)
            return {"abs": d, "pct": p}

        variacion = {k: var(kpis_a[k], kpis_b[k]) for k in kpis_a}

        # Por producto
        prod_a = df_a.groupby("producto")["venta_sin_impuestos"].sum().rename("periodo_a")
        prod_b = df_b.groupby("producto")["venta_sin_impuestos"].sum().rename("periodo_b")
        por_producto = pd.concat([prod_a, prod_b], axis=1).fillna(0)
        por_producto["variacion_abs"] = por_producto["periodo_a"] - por_producto["periodo_b"]
        por_producto["variacion_pct"] = (
            (por_producto["variacion_abs"] / por_producto["periodo_b"]) * 100
        ).replace([np.inf, -np.inf], 0).fillna(0)
        # Mantener orden canonico
        por_producto = por_producto.reindex(
            [p for p in PRODUCT_ORDER if p in por_producto.index]
        )

        # Por canal
        canal_a = df_a.groupby("canal_norm")["venta_sin_impuestos"].sum().rename("periodo_a")
        canal_b = df_b.groupby("canal_norm")["venta_sin_impuestos"].sum().rename("periodo_b")
        por_canal = pd.concat([canal_a, canal_b], axis=1).fillna(0)
        por_canal["variacion_abs"] = por_canal["periodo_a"] - por_canal["periodo_b"]
        por_canal["variacion_pct"] = (
            (por_canal["variacion_abs"] / por_canal["periodo_b"]) * 100
        ).replace([np.inf, -np.inf], 0).fillna(0)
        por_canal = por_canal.reindex(
            [c for c in CANAL_ORDER if c in por_canal.index]
        )

        # Por cliente (top 10 combinado)
        top_cli = (
            pd.concat([df_a, df_b])
            .groupby("cliente")["venta_sin_impuestos"]
            .sum()
            .nlargest(10)
            .index
        )
        cli_a = df_a[df_a["cliente"].isin(top_cli)].groupby("cliente")["venta_sin_impuestos"].sum().rename("periodo_a")
        cli_b = df_b[df_b["cliente"].isin(top_cli)].groupby("cliente")["venta_sin_impuestos"].sum().rename("periodo_b")
        por_cliente = pd.concat([cli_a, cli_b], axis=1).fillna(0)
        por_cliente["variacion_abs"] = por_cliente["periodo_a"] - por_cliente["periodo_b"]
        por_cliente["variacion_pct"] = (
            (por_cliente["variacion_abs"] / por_cliente["periodo_b"]) * 100
        ).replace([np.inf, -np.inf], 0).fillna(0)
        por_cliente = por_cliente.sort_values("periodo_a", ascending=False)

        # Etiquetas legibles
        labels = {
            "a": self._periodo_label(modo, periodo_a),
            "b": self._periodo_label(modo, periodo_b),
        }

        return {
            "modo": modo,
            "labels": labels,
            "kpis_a": kpis_a,
            "kpis_b": kpis_b,
            "variacion": variacion,
            "por_producto": por_producto,
            "por_canal": por_canal,
            "por_cliente": por_cliente,
        }

    def _filter_by_periodo(self, modo: str, periodo: Dict) -> pd.DataFrame:
        """Filtra el DataFrame según el modo y los parámetros del periodo."""
        df = self.df
        if modo == "semana":
            return df[
                (df["anio_num"] == periodo["anio"]) &
                (df["semana_num"] == periodo["semana"])
            ]
        elif modo == "mes":
            return df[
                (df["anio_num"] == periodo["anio"]) &
                (df["mes"] == periodo["mes"])
            ]
        elif modo == "anio":
            return df[df["anio_num"] == periodo["anio"]]
        else:
            raise ValueError(f"Modo no soportado: {modo}. Usa 'semana', 'mes' o 'anio'.")

    def _periodo_label(self, modo: str, periodo: Dict) -> str:
        """Genera etiqueta legible para un periodo."""
        MESES = {
            1: "Ene", 2: "Feb", 3: "Mar", 4: "Abr", 5: "May", 6: "Jun",
            7: "Jul", 8: "Ago", 9: "Sep", 10: "Oct", 11: "Nov", 12: "Dic",
        }
        if modo == "semana":
            return f"Semana {periodo['semana']:02d}-{periodo['anio']}"
        elif modo == "mes":
            mes_nombre = MESES.get(periodo["mes"], str(periodo["mes"]))
            return f"{mes_nombre}/{str(periodo['anio'])[2:]}"
        elif modo == "anio":
            return f"Anio {periodo['anio']}"
        return str(periodo)

    # ------------------------------------------------------------------
    # Público: Serie mensual por canal/producto (para el comparativo)
    # ------------------------------------------------------------------

    def get_serie_mensual(
        self,
        anio: Optional[int] = None,
        group_by: str = "producto",
        filtro: Optional[str] = None,
    ) -> pd.DataFrame:
        """Ventas mensuales del año especificado (o el año del reporte)."""
        anio = anio or self.anio
        df = self.df[self.df["anio_num"] == anio].copy()

        if filtro and group_by == "producto":
            df = df[df["producto"] == filtro]
        elif filtro and group_by == "canal":
            df = df[df["canal_norm"] == filtro]

        group_col = "producto" if group_by == "producto" else "canal_norm"
        piv = (
            df.groupby(["mes", group_col])["venta_sin_impuestos"]
            .sum()
            .unstack(fill_value=0)
        )
        piv["Total"] = piv.sum(axis=1)
        piv = piv.reset_index()
        MESES = {
            1:"Ene",2:"Feb",3:"Mar",4:"Abr",5:"May",6:"Jun",
            7:"Jul",8:"Ago",9:"Sep",10:"Oct",11:"Nov",12:"Dic",
        }
        piv["label"] = piv["mes"].map(MESES)
        return piv

    # ------------------------------------------------------------------
    # Público: Serie anual semanal completa (para Hoja Comparativo)
    # ------------------------------------------------------------------

    def get_serie_anual_semanal(self, anio: Optional[int] = None) -> pd.DataFrame:
        """
        Retorna la serie semanal completa del año indicado (o del año del reporte)
        hasta la semana actual. Incluye columna de promedio móvil de 4 semanas.

        Columnas: semana_num, label, venta_actual, venta_anio_anterior, promedio_movil_4s
        """
        anio = anio or self.anio
        df = self.df

        # Año actual hasta semana seleccionada
        df_cur = df[(df["anio_num"] == anio) & (df["semana_num"] <= self.semana)]
        serie_cur = (
            df_cur.groupby("semana_num")["venta_sin_impuestos"]
            .sum()
            .reset_index()
            .rename(columns={"venta_sin_impuestos": "venta_actual"})
        )

        # Año anterior (mismas semanas)
        df_prev = df[(df["anio_num"] == anio - 1) & (df["semana_num"] <= self.semana)]
        serie_prev = (
            df_prev.groupby("semana_num")["venta_sin_impuestos"]
            .sum()
            .reset_index()
            .rename(columns={"venta_sin_impuestos": "venta_anio_anterior"})
        )

        result = serie_cur.merge(serie_prev, on="semana_num", how="left").fillna(0)
        result = result.sort_values("semana_num").reset_index(drop=True)

        # Promedio móvil de 4 semanas (ventana anterior — no incluye la semana actual en el cálculo)
        result["promedio_movil_4s"] = (
            result["venta_actual"].rolling(window=4, min_periods=1).mean()
        )

        result["label"] = result["semana_num"].apply(lambda x: f"W{int(x):02d}")
        return result

    # ------------------------------------------------------------------
    # Público: Ventana Rolling 52 semanas
    # ------------------------------------------------------------------

    def get_rolling_52(self) -> Optional[Dict]:
        """
        Calcula la ventana de 52 semanas previas a la semana actual.
        Retorna None si no hay datos suficientes (menos de 40 semanas con datos).
        Retorna dict con ventas_rolling, ventas_rolling_ly, variacion.
        """
        y, w = self.anio, self.semana

        # Construir lista de (year, week) de las últimas 52 semanas
        periodos = []
        cy, cw = y, w
        for _ in range(52):
            periodos.append((cy, cw))
            cy, cw = _prev_week(cy, cw)

        cond = pd.Series(False, index=self.df.index)
        for ay, aw in periodos:
            cond |= (self.df["anio_num"] == ay) & (self.df["semana_num"] == aw)
        df_roll = self.df[cond]

        # Necesitamos al menos 40 semanas con datos para que sea significativo
        semanas_con_datos = df_roll.groupby(["anio_num", "semana_num"]).ngroups
        if semanas_con_datos < 40:
            return None

        kpis_roll = self._kpis(df_roll)

        # Mismo período del año anterior (52 semanas previas a la semana del año ant.)
        periodos_ly = []
        cy2, cw2 = y - 1, w
        for _ in range(52):
            periodos_ly.append((cy2, cw2))
            cy2, cw2 = _prev_week(cy2, cw2)

        cond_ly = pd.Series(False, index=self.df.index)
        for ay, aw in periodos_ly:
            cond_ly |= (self.df["anio_num"] == ay) & (self.df["semana_num"] == aw)
        df_roll_ly = self.df[cond_ly]

        kpis_ly = self._kpis(df_roll_ly)

        va = kpis_roll["ventas_netas"]
        vb = kpis_ly["ventas_netas"]
        d = va - vb
        p = (d / vb * 100) if vb != 0 else 0.0

        return {
            "semanas_incluidas": semanas_con_datos,
            "ventas_rolling": va,
            "botellas_rolling": kpis_roll["botellas"],
            "ventas_rolling_ly": vb,
            "var_abs": d,
            "var_pct": p,
            "label_a": f"Rolling 52 sem hasta S{w:02d}-{y}",
            "label_b": f"Rolling 52 sem hasta S{w:02d}-{y-1}",
        }

    # ------------------------------------------------------------------
    # Público: Clientes en riesgo y en crecimiento vs año anterior
    # ------------------------------------------------------------------

    def get_clientes_riesgo_crecimiento(
        self,
        umbral_riesgo_pct: float = -20.0,
        umbral_crecimiento_pct: float = 15.0,
        venta_minima: float = 50_000.0,
    ) -> Dict:
        """
        Compara las ventas YTD por cliente entre año actual y año anterior.
        Retorna dos DataFrames: 'riesgo' y 'crecimiento'.

        Params
        ------
        umbral_riesgo_pct     : variación % negativa mínima para calificar como riesgo (ej. -20%)
        umbral_crecimiento_pct: variación % positiva mínima para calificar como crecimiento (ej. +15%)
        venta_minima          : piso de venta en año anterior (para filtrar cuentas marginales)
        """
        y, w = self.anio, self.semana
        ly, lyw = _same_week_prev_year(y, w)

        df_cur = self._filter_ytd(y, w)
        df_ly  = self._filter_ytd(ly, lyw)

        agg_cur = df_cur.groupby("cliente")["venta_sin_impuestos"].sum().rename("venta_actual")
        agg_ly  = df_ly.groupby("cliente")["venta_sin_impuestos"].sum().rename("venta_anterior")

        merged = pd.concat([agg_cur, agg_ly], axis=1).fillna(0)
        # Filtrar piso de venta mínima en año anterior
        merged = merged[merged["venta_anterior"] >= venta_minima]

        merged["variacion_abs"] = merged["venta_actual"] - merged["venta_anterior"]
        merged["variacion_pct"] = (
            (merged["variacion_abs"] / merged["venta_anterior"]) * 100
        ).replace([np.inf, -np.inf], 0).fillna(0)

        riesgo = (
            merged[merged["variacion_pct"] <= umbral_riesgo_pct]
            .sort_values("variacion_pct")
            .head(15)
        )
        crecimiento = (
            merged[merged["variacion_pct"] >= umbral_crecimiento_pct]
            .sort_values("variacion_pct", ascending=False)
            .head(15)
        )

        return {"riesgo": riesgo, "crecimiento": crecimiento}

    # ------------------------------------------------------------------
    # Público: Análisis de canal — año actual vs anterior + participación
    # ------------------------------------------------------------------

    def get_canal_analisis(self, mode: str = "anual") -> pd.DataFrame:
        """
        DataFrame de análisis por canal con año actual vs anterior.
        Columnas: canal, unidades_actual, venta_actual, venta_anterior,
                  pct_part_actual, pct_part_anterior, var_pp
        mode: 'semanal' | 'anual'
        """
        y, w = self.anio, self.semana
        ly, lyw = _same_week_prev_year(y, w)

        if mode == "semanal":
            df_cur = self._filter_period(y, w)
            df_ly  = self._filter_period(ly, lyw)
        else:
            df_cur = self._filter_ytd(y, w)
            df_ly  = self._filter_ytd(ly, lyw)

        agg_cur = (
            df_cur.groupby("canal_norm")
            .agg(
                unidades=("botellas", "sum"),
                venta_actual=("venta_sin_impuestos", "sum"),
            )
            .reset_index()
        )
        agg_ly = (
            df_ly.groupby("canal_norm")["venta_sin_impuestos"]
            .sum()
            .reset_index()
            .rename(columns={"venta_sin_impuestos": "venta_anterior"})
        )

        merged = agg_cur.merge(agg_ly, on="canal_norm", how="outer").fillna(0)

        total_cur = merged["venta_actual"].sum()
        total_ly  = merged["venta_anterior"].sum()

        merged["pct_part_actual"]   = (merged["venta_actual"]   / total_cur * 100).fillna(0) if total_cur > 0 else 0
        merged["pct_part_anterior"] = (merged["venta_anterior"] / total_ly  * 100).fillna(0) if total_ly > 0 else 0
        merged["var_pp"] = merged["pct_part_actual"] - merged["pct_part_anterior"]

        # Orden canónico
        canal_cat = pd.CategoricalDtype(CANAL_ORDER, ordered=True)
        merged["canal_cat"] = merged["canal_norm"].astype(canal_cat)
        merged = merged.sort_values("canal_cat").drop(columns=["canal_cat"])
        merged = merged.rename(columns={"canal_norm": "canal"})

        return merged.reset_index(drop=True)

    # ------------------------------------------------------------------
    # Público: Detalle Canal → Cliente → Producto
    # ------------------------------------------------------------------

    def get_cliente_producto_por_canal(
        self,
        canal: str,
        sub_canal: Optional[str] = None,
        mode: str = "anual",
        top_n: int = 10,
    ) -> Optional[Dict]:
        """
        Pivote Cliente × Producto para un canal (y sub-canal opcional).

        Retorna dict con:
          - 'pivot'      : DataFrame index=cliente, columnas=PRODUCT_ORDER + 'Total'
                           (top_n clientes por venta + fila 'Otros' con el resto)
          - 'total'      : venta total del canal/sub-canal en el periodo
          - 'prod_tot'   : dict producto -> venta total (para fila Ventas Netas)
        mode: 'semanal' (semana del reporte) | 'anual' (YTD hasta la semana)
        Devuelve None si no hay datos.
        """
        y, w = self.anio, self.semana
        df = self._filter_period(y, w) if mode == "semanal" else self._filter_ytd(y, w)
        df = df[df["canal_norm"] == canal]
        if sub_canal is not None:
            df = df[df["sub_canal"] == sub_canal]
        if df.empty:
            return None

        piv = (
            df.groupby(["cliente", "producto"])["venta_sin_impuestos"]
            .sum()
            .unstack(fill_value=0)
        )
        for p in PRODUCT_ORDER:
            if p not in piv.columns:
                piv[p] = 0
        piv = piv.reindex(columns=PRODUCT_ORDER, fill_value=0)
        piv["Total"] = piv.sum(axis=1)
        piv = piv.sort_values("Total", ascending=False)

        total_all = float(piv["Total"].sum())

        # Top N + 'Otros'
        if len(piv) > top_n:
            top = piv.head(top_n)
            resto = piv.iloc[top_n:][PRODUCT_ORDER + ["Total"]].sum()
            resto.name = "Otros"
            piv = pd.concat([top, resto.to_frame().T])

        prod_tot = {p: float(piv[p].sum()) for p in PRODUCT_ORDER}

        return {"pivot": piv, "total": total_all, "prod_tot": prod_tot}
