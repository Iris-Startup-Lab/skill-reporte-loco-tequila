---
name: reporte_loco_tequila
description: >
  Genera el reporte semanal ejecutivo de Loco Tequila en tres formatos:
  PDF (reporte visual con paleta maroon), XLSX (6-8 hojas analiticas) y
  Dashboard HTML (interactivo, filtrable, descargable). Soporta comparaciones
  custom entre semanas, meses o años, y busqueda web de contexto de mercado
  (CRT, precio agave, NOM-006).
  Palabras clave: reporte, loco tequila, ventas, semanal, semana, pdf, xlsx,
  dashboard, html, finanzas, analisis, tequila, comparar, contexto mercado,
  CRT, agave, NOM, wow, mom, yoy, ytd.
---

# Skill: Reporte Semanal Loco Tequila

## Propósito

Genera automáticamente los tres entregables del reporte semanal de ventas y margen de **Loco Tequila**:

| Entregable | Archivo | Descripción |
| --- | --- | --- |
| **PDF** | `Reporte_Loco_Semana_NN_AAAA.pdf` | ~40 páginas con paleta maroon, tablas y gráficas (incluye detalle Canal→Cliente→Producto y tabla de histórico mensual) |
| **XLSX** | `Reporte_Ejecutivo_Loco_Semana_NN_AAAA.xlsx` | **7 hojas** ejecutivas + contexto mercado (opcional) |
| **HTML** | `Dashboard_Loco_Semana_NN_AAAA.html` | Dashboard interactivo con filtros y descarga CSV/PNG |

---

## 🤖 Protocolo de Presentación y Guía del Agente

Al activarse esta Skill, el agente **DEBE** seguir este protocolo de interacción inicial con el usuario:

### Paso 1: Presentación e Identificación de Datos

> 🚫 **NUNCA arranques directo con la pregunta de datos** (ej. *"No hay archivos
> adjuntos... necesito una cosa antes de arrancar"*). Antes de preguntar nada, el
> agente **SIEMPRE** se presenta primero — en el **mismo mensaje**, no en dos turnos
> separados — explicando en 2-3 líneas qué es esta skill y qué entrega, y solo
> entonces hace la(s) pregunta(s) que falten (Paso 3). Plantilla sugerida (puedes
> adaptar el tono, pero conserva el propósito y los 3 entregables):
>
> *"👋 Genero el **reporte semanal de ventas y margen de Loco Tequila** en 3
> formatos a partir de tus datos: un **PDF ejecutivo** (~40 págs. con tablas y
> gráficas), un **Excel analítico** (7 hojas) y un **Dashboard HTML** interactivo
> con filtros y descarga de CSV/PNG. Incluyo automáticamente 4 comparativos
> (semana anterior, año anterior, acumulado del año y rolling 52 semanas) y
> contexto de mercado (CRT, agave, NOM-006)."*
>
> Después de esa presentación (mismo mensaje), continúa con lo que corresponda:
>
> 1. **Si el usuario YA adjuntó datos (CSV o Excel, con cualquier nombre de
>    archivo) o especificó una ruta (`--datos-dir`)**: agrega una línea confirmando
>    que procede a generar el reporte con esos datos (sin preguntar nada más de
>    fuente de datos).
> 2. **Si el usuario NO ha adjuntado datos ni indicado ruta**: agrega la pregunta
>    de fuente de datos (Paso 3, Pregunta 1) al final del mismo mensaje.
> 3. Si además falta la semana/año, agrega también la Pregunta 2 (Paso 3) en ese
>    mismo mensaje — **máximo 2 preguntas en total, pero la presentación no cuenta
>    como pregunta.**

> 🚫 **REGLA CRÍTICA DE SINTAXIS Y VOCABULARIO**:
> **NUNCA** uses frases como *"No veo archivos en tu carpeta de uploads"*, *"Tu carpeta de uploads está vacía"*, *"Sigo sin ver archivos en tu carpeta"*, ni asumas que existe un monitoreo automático en segundo plano. El agente NO busca ni monitorea carpetas de uploads en segundo plano; simplemente procesa los archivos adjuntos en el chat o la ruta indicada por el usuario.

### Paso 2: Qué Debe Contener el Archivo del Cliente (NO importa el nombre del archivo ni el idioma/formato exacto de las columnas)

> ⚠️ **El agente NUNCA debe pedirle al usuario que "adjunte `loco_actuals_enriquecido.csv`"
> ni ningún otro nombre de archivo exacto.** Esos son solo los nombres del dataset de
> muestra interno (`data_for_test_and_simulation/`). El cliente sube su Excel/CSV
> **tal como lo exporta de su propio sistema** (facturación, ERP, punto de venta), con
> cualquier nombre de archivo (ej. `"Reportes de ventas 2026 semana 34 OK.xlsx"`) y
> cualquier encabezado de columna en el idioma/formato que use su sistema.

La skill necesita 1 o 2 archivos (Excel `.xlsx`/`.xls` o CSV):

| Rol | ¿Obligatorio? | Cómo se detecta |
| --- | --- | --- |
| **Ventas reales** (facturación/actuals) | **Sí** | Cualquier archivo cuyo nombre contenga "venta", "actual", "reporte" o "enriquecido" (y no diga "plan"/"presupuesto") — o, si solo hay un archivo en la carpeta, ese mismo. |
| **Plan / presupuesto** | Opcional (sin él, no hay comparativos vs Plan) | Cualquier archivo cuyo nombre contenga "plan", "presupuesto", "vs_plan" o "semanalizado". |

`scripts/data_processor.py` detecta el archivo por esas palabras clave en el **nombre
del archivo** (no por un nombre exacto), y dentro de cada archivo reconoce las
columnas por **contenido/significado**, no por un encabezado exacto — soporta
mayúsculas/minúsculas, acentos y varios sinónimos comunes por columna. Lo que
realmente necesita encontrar en el archivo de **ventas** es:

| Concepto | Encabezados que el sistema ya reconoce (ejemplos) |
| --- | --- |
| Fecha de la venta | `fecha de venta`, `Fecha de Emisión`, `Fecha de Emision`, `fecha` |
| Semana (si no hay fecha) | `Semana`, `semana`, `week` (acepta `"Semana 34"` o el número solo) |
| Producto / SKU | `SKU`, `ARTÍCULO`, `Articulo`, `producto`, `Producto` |
| Categoría de negocio | `Categoria`, `Categoría` (para distinguir venta de producto tequila de otros conceptos como Agave/Servicios — ver `metodologia_reporte.md`) |
| Cliente | `Cliente`, `CLIENTE`, `Receptor`, `receptor` |
| Canal comercial | `Canal / Reporte`, `canal`, `Canal`, `CANAL` |
| Región / estado | `Ubicación`, `Ubicacion`, `Region`, `estado`, `Estado` |
| Unidades vendidas | `Unidades`, `unidades`, `unidades_de_venta`, `cantidad` |
| Precio unitario | `Importe`, `importe`, `precio`, `Precio` |
| Venta sin impuestos | `Venta`, `venta`, `VENTA NETA (MXN)`, `subtotal` |
| Venta con impuestos | `Monto`, `monto`, `Venta + IVA`, `total` |
| Estatus de la factura | Cualquier columna con "estatus" o "status" en el nombre (se descartan filas `Cancelado` y filas de "Total" sin estatus) |
| Cajas de 9L (opcional) | `Cajas 9 lts`, `cajas_9_lts` — si no viene, se calcula automáticamente |

Si alguna columna no existe en absoluto, el sistema aplica un valor por defecto
razonable (documentado en `metodologia_reporte.md`) en vez de fallar — pero mientras
más de estas columnas traiga el archivo original, más preciso es el reporte.

**Ejemplo real de un archivo de cliente válido** (encabezados tal como los exporta su
sistema de facturación, sin ninguna transformación previa):

```csv
Mes,Folio fiscal,Tipo Comprobante,Categoria,Semana,RFC,Receptor,Cajas 9 lts,Unidades,SKU,Precio unitario,Venta,IEPS,IVA,Fecha de Emisión,Estatus,Canal,Canal / Reporte,Cliente,Ubicación,Costo unitario,Margen
8,f5a673e2-...,FACTURA,Producto (Botellas),Semana 34,DTO140207MW0,DOS CON TODO,0.25,3,Loco Blanco,1450.00,4350.00,652.50,696.00,2026-08-20,Vigente,On Trade,On Trade,Parker and Lenox,CDMX,518.20,2164.13
```

Para el **Plan/presupuesto** (opcional), el sistema reconoce columnas equivalentes
(`ARTÍCULO`/SKU, `CANAL`, `UNIDADES`, `VENTA NETA (MXN)`, `COGS`, `SEMANA`, etc.) — no
necesita traer el formato canónico interno tampoco.

Si el usuario tiene dudas de si su archivo sirve, la respuesta correcta es "sí, adjunta
tu Excel/CSV tal como lo tengas" — nunca pedirle que lo renombre o reformatee primero.

### Paso 3: Preguntas de Aclaración Iniciales (MÁXIMO 2 PREGUNTAS)

El agente solo puede realizar **hasta 2 preguntas de aclaración** antes de generar los reportes, y únicamente si dicha información no fue incluida por el usuario en su mensaje inicial:

#### 1. Pregunta 1: Fuente de Datos (solo si no se adjuntaron datos ni ruta)

Si el usuario **no** ha adjuntado archivos (CSV o Excel) ni ha especificado una ruta de datos:
> *"¿Con qué datos genero el reporte?*
>
> 1. *Tus **datos propios** (Excel o CSV, tal como los exportas de tu sistema, con cualquier nombre de archivo — puedes adjuntarlos aquí en el chat o indicarme la ruta de la carpeta).*
> 2. *Los **datos de muestra incluidos** (`data_for_test_and_simulation/` — Semana 30 de 2026).*

#### 2. Pregunta 2: Periodo / Semana Base a Comparar (solo si el usuario no especificó semana y año)

Si el usuario **no** especificó en su mensaje el número de semana y año base a evaluar:
> *"¿Qué **semana y año base** deseas evaluar y comparar en el reporte? (Ejemplo: Semana 30 de 2026)."*

*Nota*: Si el usuario elige la opción 2 (datos de muestra) y no especifica semana ni año, se toma por defecto la **Semana 30 de 2026** (`--semana 30 --anio 2026`). Si el usuario proporciona toda la información en su mensaje inicial (datos + semana/año), el agente realiza **0 preguntas** y ejecuta de inmediato.

Una vez respondidas las preguntas necesarias, el agente **genera directamente los 3 entregables sin más interrupciones**.

### Reglas de comportamiento del agente (IMPORTANTE)

1. **Siempre genera los 3 formatos** (PDF + XLSX + HTML) en una sola corrida.
   **Nunca** preguntes qué formato quiere el usuario ni uses `--solo` salvo
   petición explícita del usuario.
2. **Nunca** preguntes por comparativos adicionales / custom. Los 4 comparativos
   fijos (ver §Ventanas Comparativas) ya vienen incluidos automáticamente y son
   los únicos que se reportan. **No uses** `--modo-comparar` salvo que el usuario
   lo pida explícitamente con palabras.
3. **No** hagas preguntas de contexto innecesarias (imágenes, logos, colores,
   temas, etc.). Todo eso ya está resuelto por defecto.
4. **El contexto de mercado (CRT/agave/NOM) es SIEMPRE OBLIGATORIO.** En CADA
   reporte, antes de generar el archivo final, el agente **debe** buscar en la
   web y llenar el contexto de mercado (ver §Contexto de Mercado Externo). No es
   opcional y **no** se pregunta al usuario: se ejecuta siempre de forma
   automática. Solo si la búsqueda web falla por completo se genera el reporte
   con el placeholder de contexto.

---

## Ventanas Comparativas por Defecto (las 4 que SIEMPRE se reportan)

El XLSX incluye **siempre y automáticamente** las siguientes 4 ventanas
comparativas en la Hoja "Comparativo Periodos". El agente **no pregunta nada**
y **no necesita parámetros adicionales** para generarlas:

| Bloque | Ventana | Descripción |
| --- | --- | --- |
| **A** | Semana anterior | Semana seleccionada vs **la semana inmediata anterior** |
| **B** | Misma semana año anterior | Semana seleccionada vs **la misma semana del año anterior** |
| **C** | Acumulado YTD vs año anterior | **Acumulado** S01–SNN del año en curso vs el **mismo acumulado** hasta esa semana del año anterior |
| **D** | Rolling 52 semanas | Últimas 52 semanas vs las mismas 52 del año anterior (**solo si hay ≥ 40 semanas con datos**) |

Estas 4 ventanas corresponden exactamente a lo que el negocio requiere comparar y
**son las únicas** comparaciones que se incluyen por defecto. Además, la hoja
incluye la **serie semanal completa del año** (con columna de año anterior +
promedio móvil de 4 semanas) y una gráfica de líneas.

> **Nota:** El agente **no** debe ofrecer ni solicitar comparativos adicionales.
> Solo si el usuario, por iniciativa propia, pide una comparación distinta
> (ej. "compárame la semana 30 con la 25"), el agente usa `--modo-comparar`.

---

## Cómo invocar (comandos básicos)

```powershell
# Activar entorno Conda:
& "E:\Users\1167486\AppData\Local\anaconda3\Scripts\conda.exe" shell.powershell hook | Out-String | Invoke-Expression
conda activate data_analytics_science

# Reporte completo (los 3 formatos) — ESTE es el uso por defecto:
python scripts/generate_report.py --semana 30 --anio 2026 `
    --datos-dir data_for_test_and_simulation `
    --output-dir output

# --solo SOLO se usa si el usuario lo pide explícitamente (no preguntar por esto):
python scripts/generate_report.py --semana 30 --anio 2026 --solo pdf
python scripts/generate_report.py --semana 30 --anio 2026 --solo xlsx
python scripts/generate_report.py --semana 30 --anio 2026 --solo html
```

---

## Comparaciones entre periodos

El usuario puede pedir comparar semanas, meses o años. El agente debe traducir
la pregunta a los parámetros correctos:

### Comparar dos semanas

```powershell
# "Compara la semana 30 con la semana 25 de 2026"
python scripts/generate_report.py --semana 30 --anio 2026 --solo xlsx `
    --modo-comparar semana --comparar-semana 25 --comparar-anio 2026
```

### Comparar dos meses

```powershell
# "Compara julio contra mayo de 2026"
python scripts/generate_report.py --semana 30 --anio 2026 --solo xlsx `
    --modo-comparar mes --comparar-mes 5 --comparar-anio 2026
# (mes actual = 7 julio, comparar-mes = 5 mayo)
```

### Comparar dos años

```powershell
# "Compara 2026 contra 2025 en ventas acumuladas"
python scripts/generate_report.py --semana 30 --anio 2026 --solo xlsx `
    --modo-comparar anio --comparar-anio 2025
```

> **Nota para el agente:** Al detectar una pregunta de comparación, identificar:
>
> 1. El modo: ¿es semana vs semana, mes vs mes, año vs año?
> 2. El periodo A (el más reciente / el de la semana del reporte)
> 3. El periodo B (el de comparación)
> 4. Ejecutar el comando XLSX con --modo-comparar y los parámetros correctos

### Ejemplos de preguntas conversacionales → comando

| Pregunta del usuario | Comando resultante |
| --- | --- |
| "¿Cómo fue la semana 30 vs la 25?" | `--modo-comparar semana --comparar-semana 25` |
| "Compara junio con mayo" | `--modo-comparar mes --comparar-mes 5` |
| "¿Cómo van las ventas YTD vs el año pasado?" | `--modo-comparar anio --comparar-anio 2025` |
| "¿Cuánto creció Loco Blanco esta semana vs la anterior?" | `--modo-comparar semana --comparar-semana 29` |

---

## Contexto de Mercado Externo

### ¿Qué es CRT / Agave / NOM?

| Término | Significado | Por qué importa para el reporte |
| --- | --- | --- |
| **CRT** | Consejo Regulador del Tequila — publica estadísticas mensuales de producción y exportaciones | Permite saber si la caída/crecimiento de Loco es interna o de todo el mercado |
| **Precio del Agave** | Precio por tonelada del agave azul Weber (materia prima del tequila) | Cuando sube, el margen de la empresa se comprime aunque las ventas crezcan |
| **NOM-006** | Norma Oficial Mexicana que regula qué puede llamarse "Tequila" | Cambios en categorías, etiquetado o zonas de producción afectan estrategia de producto |

### Flujo OBLIGATORIO de contexto de mercado (ejecutar SIEMPRE)

⚠️ **Este flujo se ejecuta en CADA reporte, sin excepción y sin preguntar.** El
contexto de mercado se busca **ANTES** de generar los archivos, y la generación
final se hace **en una sola corrida** pasando `--contexto-mercado`. Nunca generes
el reporte "primero" y el contexto "después": el orden correcto es buscar → llenar
el .txt → generar todo con `--contexto-mercado`.

**Paso 1 — Ver las queries sugeridas:**

```powershell
python scripts/generate_report.py --semana 30 --anio 2026 `
    --mostrar-queries-mercado
```

**Paso 2 — Buscar en web** (el agente usa su herramienta de búsqueda web / `search_web` / `WebSearch`).
Debe buscar, como mínimo, estos temas del año del reporte:

```
Buscar: "CRT Consejo Regulador Tequila estadisticas produccion exportacion 2026"
Buscar: "precio agave azul tequila Mexico 2026 tonelada"
Buscar: "NOM-006 tequila cambios regulacion 2026"
Buscar: "exportaciones tequila Estados Unidos Europa 2026"
```

**Paso 3 — Generar el template de contexto:**

```powershell
python scripts/generate_report.py --semana 30 --anio 2026 `
    --generar-template-mercado
# Genera: output/template_contexto_mercado_S30_2026.txt
```

**Paso 4 — El agente llena el template** con el resumen de lo encontrado en web.
**Obligatorio** incluir al menos 2 líneas con el formato estructurado (así se
extraen automáticamente como hallazgos de Riesgo/Oportunidad):

```
RIESGO: Precio del agave subio 15% en Q2-2026, comprimiendo margen estimado
OPORTUNIDAD: Exportaciones a EE.UU. crecen 8% YoY, canal export a impulsar
```

**Paso 5 — Generar el reporte completo CON contexto** (los 3 formatos en una sola corrida):

```powershell
python scripts/generate_report.py --semana 30 --anio 2026 `
    --datos-dir data_for_test_and_simulation `
    --contexto-mercado output/template_contexto_mercado_S30_2026.txt
```

Esto agrega la hoja "Contexto Mercado" al XLSX (y la sección correspondiente al
PDF) con los hallazgos estructurados.

> **Fallback:** solo si la búsqueda web no está disponible o falla por completo,
> genera el reporte sin `--contexto-mercado`. En ese caso la hoja "Contexto
> Mercado" muestra el placeholder. Esto es la excepción, no la norma.

### Instrucción al agente (SIEMPRE, en todos los reportes)

En **todos** los reportes el agente debe, sin preguntar:

1. Ejecutar `--mostrar-queries-mercado` para obtener las queries
2. Usar su herramienta de búsqueda web para buscar cada query
3. Resumir los hallazgos en el formato RIESGO:/OPORTUNIDAD:
4. Escribir el resumen en un archivo .txt (usar `--generar-template-mercado` como base)
5. Generar el reporte completo pasando `--contexto-mercado <archivo>`

---

## Parámetros completos del CLI

| Parámetro | Requerido | Default | Descripción |
| --- | --- | --- | --- |
| `--semana` | ✅ | — | Semana ISO (1–53) del reporte principal |
| `--anio` | ✅ | — | Año del reporte (ej. 2026) |
| `--datos-dir` | ❌ | `data_for_test_and_simulation` | Carpeta con los CSVs |
| `--output-dir` | ❌ | `output` | Carpeta de salida |
| `--logo` | ❌ | `assets/Loco_Tequila_Logo.svg` | Ruta al logo |
| `--solo` | ❌ | (todos) | `pdf` \| `xlsx` \| `html` |
| `--top-clientes` | ❌ | `6` | Número de clientes top |
| `--modo-comparar` | ❌ | — | `semana` \| `mes` \| `anio` |
| `--comparar-semana` | ❌ | — | Semana B (con `--modo-comparar semana`) |
| `--comparar-mes` | ❌ | — | Mes B 1-12 (con `--modo-comparar mes`) |
| `--comparar-anio` | ❌ | — | Año B (con cualquier `--modo-comparar`) |
| `--contexto-mercado` | ❌ | — | Ruta a .txt con contexto CRT/agave/NOM |
| `--generar-template-mercado` | ❌ | — | Crea el template de contexto y sale |
| `--mostrar-queries-mercado` | ❌ | — | Muestra queries de búsqueda web y sale |

---

## Estructura de archivos

```
skill_reporte/
├── SKILL.md                               <- Este archivo
├── previous_prompt.txt                    <- Prompt original del agente financiero
├── requirements.txt                       <- Dependencias Python
├── designs/
│   ├── Design.md                          <- Sistema de diseño (paleta, layout)
│   └── storytelling_summary.md            <- Resumen por capítulos de Storytelling with Data
├── assets/
│   ├── Loco_Tequila_Logo.svg
├── data_for_test_and_simulation/
│   ├── loco_actuals_enriquecido.csv        <- INPUT obligatorio (ventas reales)
│   └── loco_actual_vs_plan_semanal.csv     <- INPUT opcional (plan vs real)
├── scripts/
│   ├── generate_report.py     <- Orquestador CLI (ENTRADA PRINCIPAL)
│   ├── data_processor.py      <- Carga, limpia, calcula KPIs y comparativos
│   ├── pdf_generator.py       <- PDF ~30 pags (ReportLab + matplotlib)
│   ├── xlsx_generator.py      <- XLSX 6-8 hojas (openpyxl)
│   ├── dashboard_generator.py <- HTML filtrable (Chart.js CDN)
│   ├── market_context.py      <- Contexto CRT/agave/NOM
│   └── design_tokens.py       <- Paleta maroon, SKUs, canales
└── output/                    <- Archivos generados (creada automáticamente)
```

---

## Qué analiza el reporte (conforme al previous_prompt.txt)

| Sección del prompt original | Cobertura |
| --- | --- |
| Comparativos WoW, MoM, YoY, YTD | ✅ Hoja 2 XLSX: 4 bloques por defecto (WoW, YoY semanal, YTD vs LY, Rolling 52) + serie anual completa |
| Patrones por producto (ranking 8-12 sem.) | ✅ Hoja 3 XLSX: ranking YTD + tendencia 12 sem + tabla Ascendente/Estable/Descendente |
| Patrones por cliente (concentración, riesgo) | ✅ Hoja 4 XLSX: top 5%/10% cartera + Pareto + Clientes en Riesgo + Clientes en Crecimiento |
| Análisis regional por estado | ✅ Hoja 5 XLSX: ventas estado año actual vs anterior + variación pp coloreada |
| Análisis por canal de distribución | ✅ Hoja 6 XLSX: nueva hoja separada con barra apilada 100% |
| Oportunidades y riesgos (internos) | ✅ Hoja 7 XLSX (automático, fondo completo en columna Tipo) |
| Contexto de mercado (CRT, agave, NOM) | ✅ Hoja 8 XLSX (requiere búsqueda web) |
| Conclusiones y Próximos Pasos | ✅ Hoja 7 XLSX (5 puntos) |
| Semáforo WoW/YoY/YTD/Plan + Lectura | ✅ Hoja 1 XLSX (columna narrativa automática) |
| Comparativo custom dos periodos | ✅ Hoja extra XLSX (con --modo-comparar) |

---

## Principios de visualización

- **Sin donas para análisis de tendencia** — solo en resumen (págs 1-2 PDF)
- **Mix de producto (resumen PDF):** el gráfico se elige según el número de
  productos con venta:
  - **≤ 3 productos → dona** clásica, con el total al **centro**.
  - **> 3 productos → treemap de Voronoi** (áreas proporcionales a la venta),
    con el total **arriba** del gráfico. Es más legible que una dona con muchas
    categorías. Lo implementan `make_voronoi_chart()` / `_voronoi_treemap_cells()`
    en `pdf_generator.py` (power diagram + relajación de Balzer/Lloyd, sin
    dependencias extra).
- **Barras agrupadas/apiladas + línea** para tendencias semanales y comparativos
- **Barras horizontales** para rankings (productos, clientes, regiones)
- **Combo chart** (área año pasado + barras + línea plan) para páginas SKU/canal

---

## 🔧 Notas Técnicas y Solución de Problemas

### Ejes de las gráficas en Excel (se dibujan automáticamente)

Las gráficas del XLSX **ya muestran sus ejes de forma automática** al abrir el
archivo. **No** es necesario aplicar manualmente "Diseño de gráfico → Diseño
rápido → Diseño 3" (ese parche fue retirado).

- **Causa raíz que se corrigió:** openpyxl (3.1.x) crea *ambos* ejes con
  `axPos="l"` (los dos a la izquierda) y sin el elemento `<c:delete>`. Con ambos
  ejes a la izquierda Excel no puede dibujar el eje horizontal de categorías y
  solo se veían las líneas de cuadrícula.
- **Solución:** la función `_fix_chart_axes()` en `xlsx_generator.py` se aplica a
  toda gráfica (vía `_add_chart_with_note`) y fija:
  - `delete = False` en ambos ejes → `<c:delete val="0"/>` (eje visible);
  - posición correcta según orientación: gráficas verticales `catAx="b"` /
    `valAx="l"`; gráficas de barras horizontales `catAx="l"` / `valAx="b"`;
  - `tickLblPos="nextTo"` y `majorTickMark="out"`.

> Si al agregar una gráfica nueva no se ven los ejes, asegúrate de insertarla con
> `_add_chart_with_note(...)` (que aplica el fix) y **no** con `ws.add_chart(...)`
> directamente.

### Formato de moneda en Excel

Todas las variables monetarias del XLSX se muestran con signo `$` al inicio y
separador de miles con comas (`"$"#,##0`; el ticket promedio con 1 decimal,
`"$"#,##0.0`). Los conteos (botellas, cajas) usan `#,##0` **sin** `$`; los
porcentajes usan formato `%` y las variaciones muestran el signo (`+/-`).

### Comparativas del Resumen Ejecutivo (todas las métricas)

La tabla "KPIs Clave" de la Hoja 1 y las tablas de detalle por SKU del PDF
incluyen las comparativas **de todas las métricas**, no solo de Ventas Netas:
`Valor · Plan · Var vs Plan · Var vs Plan % · Año Anterior · Var vs Año Ant. ·
Var vs Año Ant. %` para Ventas Netas, # Botellas, Cajas 9L, Margen % (variación
en puntos porcentuales, `pp`) y Ticket Promedio.

### Hoja "Contexto Mercado" (siempre presente)

La hoja **siempre se genera**:

- **Con** `--contexto-mercado <archivo.txt>` → trae el contexto real (resumen,
  hallazgos Riesgo/Oportunidad y fuentes). **Este es el flujo obligatorio** (ver
  §Contexto de Mercado Externo): el agente busca en web y llena el `.txt` en cada
  reporte.
- **Sin** ese parámetro → la hoja muestra un *placeholder* indicando que falta el
  contexto. Esto es solo el fallback cuando la búsqueda web no está disponible.

> ⚠️ Si ves el placeholder en la hoja de contexto, significa que el reporte se
> generó **sin** `--contexto-mercado`. Repite el flujo obligatorio: buscar en web →
> llenar el `.txt` → regenerar pasando `--contexto-mercado`.

### Páginas nuevas del PDF: Canal → Cliente → Producto

Tras la hoja de resumen (la que trae el Voronoi/dona) se genera el detalle
**Canal → Cliente → Producto**, en dos bloques: uno **Anual (YTD)** justo después
del resumen anual y otro **Semanal** justo después del resumen semanal. Cada
bloque tiene una sección por canal (Off Trade → Tradicional / Moderno + Total Off
Trade, más On Trade, Venta Directa y Familia y Amigos) con una tabla clientes ×
productos (top 10 + fila "Otros"), columna Total con %, y filas de "Ventas Netas"
y "Participación %". La paginación es automática (`_draw_pages_canal_cliente_producto`
en `pdf_generator.py`, apoyada en `get_cliente_producto_por_canal()`): las tablas
largas se parten entre páginas repitiendo el encabezado.

### Página nueva del PDF: Histórico Mensual — Tabla por Producto

Justo **después** de la gráfica de histórico mensual se agrega una hoja con la
**misma información en tabla**: meses en filas × productos en columnas + Total
(`_draw_page_historico_tabla`, reutiliza `get_historico_mensual()`, mismas
etiquetas de mes que la gráfica).

### Tablas comparativas de 8 columnas: categoría al centro

Las tablas comparativas de **8 columnas** ("Ventas Totales Por Producto" y
"…Por Canal", `_draw_kpi_table`) usan el diseño empresarial con la **categoría al
centro**: valores **reales a la izquierda** (Año Ant. · Plan · Actual resaltado),
**categoría al centro** y **variaciones a la derecha** (vs Plan y vs Año Ant.),
con separadores verticales entre grupos. Las demás tablas (incluida la de detalle
SKU, de 9 columnas) **no cambian**. `_build_rl_table` admite `label_col`,
`label_align` y `sep_before_cols` para este layout.

### Dashboard HTML

- **Oportunidades y Riesgos:** cuando se genera con `--contexto-mercado`, el HTML
  **fusiona los hallazgos de mercado** (CRT/agave/NOM) en la sección y **elimina**
  la tarjeta placeholder "Contexto de mercado no disponible". El contexto se carga
  una sola vez en `generate_report.py` y se pasa tanto a XLSX como a HTML.
- **Filtro Cliente:** es un **listado desplegable** (`<select>`, ordenado
  alfabéticamente) como los demás filtros, no una búsqueda por texto.
- **Línea de año anterior (gris):** "Ventas Netas Semanales" lleva **una sola**
  línea gris punteada y "Ventas por Producto por Semana" lleva **dos** líneas
  (Plan en rojo + Año Anterior en gris). El gris (`CHART_LASTYEAR_LINE`) es
  deliberadamente discreto para no robar foco a las barras. La serie se alinea
  por etiqueta del eje X: `2026-W30` toma el valor de `2025-W30`; las semanas sin
  histórico van en `null` para que la línea se **corte** en vez de caer a cero.
  Respeta los filtros de Producto, Canal, Estado y Cliente.
- **Línea de plan filtrada:** `plan_detail` lleva el plan desglosado por producto
  y canal, de modo que la línea roja respeta esos dos filtros. El plan de origen
  **no trae Estado ni Cliente**, así que esos filtros no lo afectan (igual que el
  KPI "Plan Est.").
- **Stacking de las líneas:** cada dataset de línea lleva su propio `stack`
  (`'plan'` / `'ly'`). En gráficas con eje Y apilado, Chart.js agrupa por
  `stack || type`; sin ese id las dos líneas se sumarían entre sí.
- **Modal "⛶ Ampliar":** cada una de las 5 gráficas tiene, junto al botón PNG, un
  botón que abre la gráfica a pantalla casi completa con botón **✕ Cerrar**
  (también cierra con `Esc` o clic en el fondo). Las gráficas se construyen desde
  `chartFactories[key]()`, que devuelve datasets **nuevos** en cada llamada: la
  instancia del modal es independiente de la de la tarjeta (Chart.js muta los
  objetos dataset, así que compartirlos rompe ambas). Si se cambian los filtros
  con el modal abierto, este se refresca solo.

---

## Dependencias Python

```powershell
pip install reportlab svglib matplotlib openpyxl chardet pandas numpy
```
